# Proper Sitting Posture Guidelines

## UCLA Health Recommendations

Sitting for prolonged periods can be a major cause of back pain, causing increased stress on the back, neck, arms, and legs, and adding pressure to back muscles and spinal discs. Poor sitting posture and workplace ergonomics over time can damage spinal structures and contribute to recurrent episodes of neck or back pain.

### Guidelines for Proper Sitting Posture

1. **Elbow measure**
   - Sit comfortably as close as possible to your desk
   - Upper arms should be parallel to your spine
   - Elbows should be at a 90-degree angle
   - Adjust chair height if needed

2. **Thigh measure**
   - You should be able to easily slide your fingers under your thigh at the leading edge of the chair
   - If too tight, prop feet up with an adjustable footrest
   - If more than a finger width between thigh and chair, raise the desk/work surface

3. **Calf measure**
   - With buttocks against chair back, try to pass a clenched fist between the back of your calf and the front of your chair
   - If you can't do this easily, the chair is too deep
   - Adjust backrest forward, insert lumbar support, or get a new chair

4. **Lower-back support**
   - Buttocks should be pressed against the back of your chair
   - Use a cushion that causes your lower back to arch slightly
   - Never slump or slouch, as this places extra stress on your spine and lumbar discs

5. **Eye level**
   - Your gaze should be aimed at the center of your computer screen
   - Adjust screen height if needed
   - For bifocal wearers, adjust screen to avoid tilting neck back

6. **Armrest**
   - Adjust armrests to slightly lift your arms at the shoulders
   - This reduces strain on neck and shoulders
   - Helps prevent slouching forward

### Important Note
No matter how comfortable your sitting position is, prolonged static posture is not good for your back. Remember to stand, stretch, and walk for at least a minute or two every half hour to keep joints, ligaments, muscles, and tendons loose.

## Alternative Seating Options
- Swedish kneeling chair: Promotes good posture without back support
- Swiss exercise ball: Helps develop abdominal and back muscles while sitting
- Consult with a doctor before using these alternatives if you have an injured back or other health problems

Source: UCLA Health - Spine Care, Ergonomics for Prolonged Sitting
