# Guide to Good Posture

## MedlinePlus Recommendations

Good posture is about more than standing up straight so you can look your best. It is an important part of your long-term health. Making sure that you hold your body the right way, whether you are moving or still, can prevent pain, injuries, and other health problems.

### Types of Posture

- **Dynamic posture**: How you hold yourself when you are moving, like when you are walking, running, or bending over to pick up something.
- **Static posture**: How you hold yourself when you are not moving, like when you are sitting, standing, or sleeping.

It is important to make sure that you have good dynamic and static posture.

### Key Principles of Good Posture

The key to good posture is the position of your spine. Your spine has three natural curves - at your neck, mid back, and low back. Correct posture should maintain these curves, but not increase them. Your head should be above your shoulders, and the top of your shoulder should be over the hips.

### Health Effects of Poor Posture

Poor posture can be bad for your health. Slouching or slumping over can:

- Misalign your musculoskeletal system
- Wear away at your spine, making it more fragile and prone to injury
- Cause neck, shoulder, and back pain
- Decrease your flexibility
- Affect how well your joints move
- Affect your balance and increase your risk of falling
- Make it harder to digest your food
- Make it harder to breathe

### General Posture Improvement Tips

- **Be mindful of your posture** during everyday activities
- **Stay active** - Yoga, tai chi, and core-strengthening exercises are especially helpful
- **Maintain a healthy weight** to prevent weakening of abdominal muscles
- **Wear comfortable, low-heeled shoes** to maintain balance
- **Ensure work surfaces are at a comfortable height** for all activities

### Improving Sitting Posture

- Switch sitting positions often
- Take brief walks around your office or home
- Gently stretch your muscles every so often
- Don't cross your legs; keep your feet on the floor
- Make sure that your feet touch the floor or use a footrest
- Relax your shoulders; they should not be rounded or pulled backwards
- Keep your elbows in close to your body (bent between 90-120 degrees)
- Ensure your back is fully supported with proper lumbar support
- Make sure that your thighs and hips are supported and parallel to the floor

### Improving Standing Posture

- Stand up straight and tall
- Keep your shoulders back
- Pull your stomach in
- Put your weight mostly on the balls of your feet
- Keep your head level
- Let your arms hang down naturally at your sides
- Keep your feet about shoulder-width apart

Source: MedlinePlus - Guide to Good Posture
