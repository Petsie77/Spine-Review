# Lumbar Spinal Stenosis Exercises

## Exercises from "Top 5 Lumbar Spinal Stenosis Exercises & Stretches" by Doctor Jo

Lumbar spinal stenosis can press on the spinal cord and the nerves that travel through the spine. Symptoms include pain or cramping in the legs when standing for long periods or when walking. These exercises and stretches are designed to help relieve lumbar spinal stenosis pain.

### Key Exercise Categories:

1. **Lower Back and Gluteus Stretches**
   - Purpose: To take pressure off the spine
   - Benefits: Relieves compression on spinal nerves

2. **Dead Bug Progression**
   - Includes: Pelvic tilt and movement of arms and legs
   - Key Component: Master the pelvic tilt first as it's the most important part
   - Benefits: Strengthens core while maintaining neutral spine position

3. **Bird Dog Progression in Quadruped**
   - Purpose: Strengthens the core and improves general stability
   - Benefits: Improves balance while supporting proper spine alignment

### Important Notes:

- Lumbar spinal stenosis often occurs with age
- Symptoms typically ease when bending forward or sitting down
- These exercises focus on creating space in the spine and strengthening supporting muscles
- A proper exercise program can help manage symptoms and potentially avoid surgery

Source: YouTube - "Top 5 Lumbar Spinal Stenosis Exercises & Stretches" by Ask Doctor Jo
