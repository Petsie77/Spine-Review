# Spine Exercises from Spine-Health.com

## 12-Minute Exercise Routine for Low Back Pain

This exercise routine is designed by Natalie Ullrich, PT, DPT, OCS, Physical Therapist, to help with low back pain. The routine focuses on improving back mobility and core strength.

### Exercise List:

1. **Pelvic Tilt**
   - Position: Lie on the ground or on your bed with feet bent
   - Technique: Draw belly button in towards spine, causing back to round and push into the ground
   - Hold: 10 seconds
   - Repetitions: 10
   - Benefits: Activates core muscles and improves lower back mobility

2. **Prone Press-Up**
   - Position: Lie on belly with hands on either side of shoulders
   - Technique: Press upper body up while keeping hips on the ground
   - Hold: 5 seconds
   - Repetitions: 10
   - Modification: If too difficult, can modify by coming up onto elbows only
   - Benefits: Extends the spine and can help relieve pressure on spinal discs

3. **Straight Leg Raise**
   - Position: Lie on back with one knee bent and one leg straight
   - Technique: Lift straight leg to about the level of the bent knee while keeping core tight and back against the ground
   - Repetitions: 10 for each leg
   - Benefits: Strengthens hips and core muscles
   - Note: Discontinue if this causes pain down the leg

### Key Points:

- These exercises help with back mobility and core strength
- Movements should be nice and controlled
- It's normal to feel some pressure through the low back or stretch through the front of the stomach during exercises
- Discontinue any exercise that causes pain or worsens symptoms
- Consult with a medical provider before starting any new exercise program

Source: Spine-Health.com - "12-Minute Exercise Routine for Low Back Pain [Real-Time] Video" by Natalie Ullrich, PT, DPT, OCS
