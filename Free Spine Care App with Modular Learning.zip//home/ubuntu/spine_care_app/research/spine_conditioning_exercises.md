# Spine Conditioning Program

## American Academy of Orthopaedic Surgeons (AAOS) Recommendations

This spine conditioning program is designed to help return to daily activities and enjoy a more active, healthy lifestyle after an injury or surgery. Following a well-structured conditioning program can also help return to sports and other recreational activities.

### Key Benefits

- **Strength:** Strengthening the muscles that support your spine will help keep your back and upper body stable. Keeping these muscles strong can relieve back pain and prevent further injury.
- **Flexibility:** Stretching the muscles that you strengthen is important for restoring range of motion and preventing injury. Gently stretching after strengthening exercises can help reduce muscle soreness and keep your muscles long and flexible.

### Target Muscles

The muscle groups targeted in this conditioning program include:
- Cervical spine (neck)
- External oblique rotators (side and lower back)
- Trapezius (neck and upper back)
- Internal oblique rotators (side and lower back)
- Latissimus dorsi (side and middle back)
- Piriformis (buttocks)
- Back extensors and erector spinae
- Gluteus maximus (buttocks)
- Gluteus medias (buttocks)
- Quadratus lumborum (lower back)
- Hamstrings (back of thigh)
- Abdominals

### Program Duration and Frequency

This spine conditioning program should be continued for 4 to 6 weeks, unless otherwise specified by a doctor or physical therapist. After recovery, these exercises can be continued as a maintenance program for lifelong protection and health of the spine. Performing the exercises 2 to 3 days a week will maintain strength and range of motion in the back.

### Getting Started Guidelines

1. **Warm up:** Before doing exercises, warm up with 5 to 10 minutes of low impact activity, like walking or riding a stationary bicycle.

2. **Stretch:** After the warm-up, do stretching exercises before moving on to strengthening exercises. When strengthening exercises are completed, repeat the stretching exercises to end the program.

3. **Do not ignore pain:** You should not feel pain during an exercise. Talk to your doctor or physical therapist if you have any pain while exercising.

4. **Ask questions:** If you are not sure how to do an exercise, or how often to do it, contact your doctor or physical therapist.

### Recommended Exercises

1. **Head Rolls**
   - Repetitions: 3 sets of 3
   - Frequency: Daily
   - Main muscles worked: Cervical spine muscles, trapezius
   - Technique: Gently bring chin toward chest, roll head to right and left, then in clockwise and counterclockwise circles

2. **Kneeling Back Extension**
   - Repetitions: 10
   - Frequency: Daily
   - Main muscles worked: Quadratus lumborum, erector spinae
   - Technique: Begin on hands and knees, rock forward and backward while extending and flexing the spine

3. **Sitting Rotation Stretch**
   - Repetitions: 2 sets of 4
   - Frequency: Daily
   - Main muscles worked: Piriformis, external and internal oblique rotators
   - Technique: Sit with one leg crossed over the other, twist toward bent leg and hold

4. **Modified Seat Side Straddle**
   - Repetitions: 10 each side
   - Frequency: Daily
   - Main muscles worked: Hamstrings, extensor muscles, erector spinae
   - Technique: Sit with one leg extended to the side and the other bent, bend toward extended leg

5. **Knee to Chest**
   - Repetitions: 3 sets of 10
   - Frequency: Daily
   - Main muscles worked: Quadratus lumborum
   - Technique: Lie on back, bring knee toward chest and hold

6. **Bird Dog**
   - Repetitions: 5
   - Frequency: Daily
   - Main muscles worked: Back extensors, erector spinae, gluteal muscles
   - Technique: Start on hands and knees, extend opposite arm and leg while maintaining balance

Source: American Academy of Orthopaedic Surgeons (AAOS) - Spine Conditioning Program
