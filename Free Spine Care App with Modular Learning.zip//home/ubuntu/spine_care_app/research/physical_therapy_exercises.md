# Spine Exercises from Physical Therapy Sources

## Exercises from "6 Exercises To Relieve Back Pain In 9 Minutes"

This video by a physical therapist presents six effective exercises designed to relieve lower back pain. The key principle is to stretch tight structures (hips and lower back) and strengthen weak structures (core stabilizer muscles).

### Exercise List and Timestamps:

1. **Lumbar Rotation Stretches** (0:35)
   - Targets: Lower back muscles
   - Benefits: Improves spinal mobility and relieves tension

2. **Piriformis Stretch** (2:45)
   - Targets: Piriformis muscle (deep in the buttocks)
   - Benefits: Relieves sciatic nerve pressure and hip tightness

3. **Hamstring Stretch** (4:45)
   - Targets: Back of thigh muscles
   - Benefits: Reduces pull on the pelvis and lower back

4. **Posterior Pelvic Tilt** (6:55)
   - Targets: Core and lower back
   - Benefits: Teaches proper pelvic positioning and core activation

5. **Bridges** (8:25)
   - Targets: Glutes, hamstrings, and core
   - Benefits: Strengthens key stabilizing muscles

6. **Bird Dogs** (9:25)
   - Targets: Core, back extensors, and shoulder stabilizers
   - Benefits: Improves balance and coordination while strengthening

### Key Points:

- Lower back pain is the most common complaint treated by physical therapists
- Approximately 80% of people will experience significant lower back pain in their lifetime
- These exercises are commonly prescribed as "homework" between therapy sessions
- Regular performance of these exercises can significantly reduce back pain
- The routine takes only 9 minutes to complete

Source: YouTube - "6 Exercises To Relieve Back Pain In 9 Minutes - FOLLOW ALONG" by Tone and Tighten (Physical Therapist)
