import React from "react";
import Link from "next/link";
import ModuleProgress from "@/components/ui/module-progress";
import PostureComparison from "@/components/posture/posture-comparison";
import StepByStepGuide from "@/components/ui/step-by-step-guide";

export default function SleepingPosturePage() {
  return (
    <div>
      <ModuleProgress 
        totalSections={4} 
        completedSections={0} 
        moduleTitle="Sleeping Posture & Habits" 
      />
      
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-blue-700 mb-4">Sleeping Posture & Habits</h1>
        <p className="text-gray-600">
          Learn how to optimize your sleeping position and habits to support spine health and wake up pain-free.
        </p>
      </header>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Why Sleep Posture Matters</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            We spend approximately one-third of our lives sleeping. Your sleeping position can:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
            <li><strong>Maintain or disrupt</strong> the natural curves of your spine</li>
            <li><strong>Relieve or create</strong> pressure points on joints and soft tissues</li>
            <li><strong>Support or hinder</strong> your body's overnight recovery processes</li>
            <li><strong>Affect breathing quality</strong> and sleep efficiency</li>
            <li><strong>Influence morning pain and stiffness</strong> levels</li>
          </ul>
          <p className="text-gray-700">
            Optimizing your sleep posture can lead to better sleep quality, reduced pain, and improved overall spine health.
          </p>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Best Sleeping Positions</h2>
        
        <div className="space-y-8">
          <PostureComparison
            title="Side Sleeping"
            correctImageUrl="/images/correct-side-sleeping.jpg"
            incorrectImageUrl="/images/incorrect-side-sleeping.jpg"
            correctDescription="Knees slightly bent, pillow supporting head and neck in neutral alignment, possibly a pillow between knees."
            incorrectDescription="No support between knees, head tilted up or down due to improper pillow height, shoulders hunched."
            tips={[
              "Use a pillow that keeps your head aligned with your spine",
              "Place a pillow between your knees to maintain hip alignment",
              "Slightly bend your knees toward your chest for lower back comfort",
              "Ensure your mattress allows your shoulders and hips to sink in slightly",
              "Avoid tucking your chin to your chest or extending your neck"
            ]}
          />
          
          <PostureComparison
            title="Back Sleeping"
            correctImageUrl="/images/correct-back-sleeping.jpg"
            incorrectImageUrl="/images/incorrect-back-sleeping.jpg"
            correctDescription="Neutral spine position with appropriate pillow height, possibly a small pillow under knees."
            incorrectDescription="Head pushed forward by too-high pillow, no support under knees, causing increased lower back arch."
            tips={[
              "Use a pillow that supports the natural curve of your neck",
              "Place a small pillow or rolled towel under your knees to reduce lower back pressure",
              "Avoid pillows that push your head forward",
              "Keep arms at your sides or on your abdomen, not overhead",
              "Ensure your mattress supports your body without excessive sinking"
            ]}
          />
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-3">Stomach Sleeping</h3>
            <p className="text-gray-700 mb-4">
              Stomach sleeping is generally not recommended for spine health because it:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
              <li>Forces your neck to rotate to one side for extended periods</li>
              <li>Often creates an excessive arch in the lower back</li>
              <li>Can compress nerves and blood vessels</li>
              <li>Makes it difficult to maintain neutral spine alignment</li>
            </ul>
            <p className="text-gray-700 mb-2">
              <strong>If you must sleep on your stomach:</strong>
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li>Use a very thin pillow or no pillow at all</li>
              <li>Place a thin pillow under your pelvis/hips to reduce lower back strain</li>
              <li>Consider hugging a pillow to create a slight tilt and reduce full rotation</li>
              <li>Try gradually transitioning to side sleeping</li>
            </ul>
          </div>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Choosing the Right Mattress and Pillow</h2>
        <StepByStepGuide
          title="Selecting Spine-Friendly Sleep Products"
          steps={[
            {
              title: "Mattress Firmness",
              description: "Choose medium-firm to firm for most people. Your mattress should support your body's natural curves without allowing excessive sinking. Side sleepers may need slightly softer mattresses to accommodate shoulders and hips."
            },
            {
              title: "Mattress Materials",
              description: "Memory foam conforms to your body but may retain heat. Latex offers support with more bounce. Hybrid mattresses combine coil support with foam comfort layers. Choose based on your preferences and needs."
            },
            {
              title: "Pillow Height",
              description: "Your pillow should fill the space between your head and mattress while maintaining neutral alignment. Side sleepers need thicker pillows, back sleepers need medium height, and stomach sleepers need very thin pillows."
            },
            {
              title: "Pillow Materials",
              description: "Memory foam and latex pillows provide consistent support. Buckwheat and water pillows are adjustable. Down and synthetic down offer softness but may not provide enough support for some."
            },
            {
              title: "Supportive Accessories",
              description: "Consider knee pillows for side sleeping, lumbar pillows for back sleeping, and body pillows for pregnancy or transitioning from stomach sleeping."
            }
          ]}
        />
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Healthy Sleep Habits for Spine Care</h2>
        <div className="bg-white rounded-lg shadow-md p-6">
          <ul className="list-disc pl-6 space-y-3 text-gray-700">
            <li><strong>Maintain consistent sleep and wake times</strong> to support your body's natural rhythms</li>
            <li><strong>Create a relaxing bedtime routine</strong> to reduce muscle tension before sleep</li>
            <li><strong>Avoid screen time 1 hour before bed</strong> to prevent neck strain from looking down at devices</li>
            <li><strong>Stretch gently before bed</strong> to release tension accumulated during the day</li>
            <li><strong>Replace your mattress every 7-10 years</strong> and pillows every 1-2 years</li>
            <li><strong>Get out of bed properly</strong> by rolling to your side first, then using your arms to push up to sitting</li>
            <li><strong>Avoid sleeping in recliners or couches</strong> regularly, as they rarely provide proper support</li>
            <li><strong>Address sleep disorders</strong> like sleep apnea, which can affect posture and spine health</li>
          </ul>
        </div>
      </section>
      
      <div className="flex justify-between mt-12">
        <Link href="/modules" className="bg-gray-100 hover:bg-gray-200 text-gray-800 py-2 px-4 rounded-md transition-colors">
          Back to Modules
        </Link>
        <Link href="/modules/core-strengthening" className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors">
          Next Module: Core Strengthening
        </Link>
      </div>
    </div>
  );
}
