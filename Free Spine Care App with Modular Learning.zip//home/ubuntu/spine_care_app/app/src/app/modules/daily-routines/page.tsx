import React from "react";
import Link from "next/link";
import ModuleProgress from "@/components/ui/module-progress";
import StepByStepGuide from "@/components/ui/step-by-step-guide";

export default function DailyRoutinesPage() {
  return (
    <div>
      <ModuleProgress 
        totalSections={4} 
        completedSections={0} 
        moduleTitle="Daily Spine Care Routines" 
      />
      
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-blue-700 mb-4">Daily Spine Care Routines</h1>
        <p className="text-gray-600">
          Learn how to integrate spine-friendly habits into your daily life to maintain spine health and prevent problems.
        </p>
      </header>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Morning Spine Care Routine</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            Start your day with these spine-friendly habits:
          </p>
          
          <StepByStepGuide
            title="Morning Spine Care"
            steps={[
              {
                title: "Wake Up Mindfully",
                description: "Before getting out of bed, take a moment to stretch gently. Roll to your side, then use your arms to push yourself up to a sitting position rather than sitting up directly from lying on your back."
              },
              {
                title: "Hydrate",
                description: "Drink a glass of water to rehydrate your intervertebral discs, which lose water during sleep. Proper hydration helps maintain disc health and function."
              },
              {
                title: "5-Minute Mobility Routine",
                description: "Perform gentle movements like cat-cow stretches, gentle twists, and shoulder rolls to wake up your spine and prepare it for the day ahead."
              },
              {
                title: "Mindful Posture Check",
                description: "Take 30 seconds to check your posture in the mirror. Align your ears over shoulders, shoulders over hips, and reset your posture for the day."
              },
              {
                title: "Prepare Your Environment",
                description: "Set up your workspace with proper ergonomics in mind. Adjust chair height, monitor position, and gather frequently used items within easy reach."
              }
            ]}
          />
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Workday Spine Care</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            Incorporate these practices throughout your workday:
          </p>
          
          <ul className="list-disc pl-6 space-y-3 text-gray-700">
            <li>
              <strong>20-20-20 Rule:</strong> Every 20 minutes, look at something 20 feet away for 20 seconds. 
              This reduces neck strain from looking down at screens and gives your spine a mini-break.
            </li>
            <li>
              <strong>Movement Breaks:</strong> Set a timer to stand up and move for 1-2 minutes every 30 minutes. 
              Simple movements like shoulder rolls, gentle backbends, or walking to get water can prevent stiffness.
            </li>
            <li>
              <strong>Posture Reset:</strong> Throughout the day, periodically check and reset your posture. 
              Imagine a string pulling the top of your head toward the ceiling while gently engaging your core.
            </li>
            <li>
              <strong>Breathing Breaks:</strong> Take three deep breaths every hour, expanding your ribcage fully. 
              This helps maintain mobility in your thoracic spine and reduces tension.
            </li>
            <li>
              <strong>Midday Mini-Stretch:</strong> Dedicate 5 minutes during lunch to perform targeted stretches 
              for tight areas, such as chest openers if you've been typing, or gentle twists if you've been sitting still.
            </li>
            <li>
              <strong>Hydration Schedule:</strong> Keep a water bottle at your desk and sip regularly throughout the day. 
              Staying hydrated helps maintain the health of your spinal discs.
            </li>
            <li>
              <strong>Phone Calls:</strong> Stand up and walk around during phone calls when possible. 
              This adds movement to your day and reduces sitting time.
            </li>
          </ul>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Evening Spine Care Routine</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            End your day with these spine-friendly practices:
          </p>
          
          <StepByStepGuide
            title="Evening Spine Care"
            steps={[
              {
                title: "Decompression Time",
                description: "Lie on your back with knees bent and feet flat on the floor, or with legs elevated on a chair or ottoman. This position takes pressure off your spine and allows it to decompress after a day of activity."
              },
              {
                title: "Gentle Evening Stretches",
                description: "Perform 5-10 minutes of gentle stretches focusing on areas that feel tight from the day's activities. Include child's pose, gentle twists, and hamstring stretches to release tension."
              },
              {
                title: "Heat Therapy (Optional)",
                description: "If you have chronic tension, apply a heating pad to tight muscles for 15-20 minutes. Heat increases blood flow and helps muscles relax before sleep."
              },
              {
                title: "Screen-Free Wind-Down",
                description: "Reduce screen time 1 hour before bed to prevent neck strain from looking down at devices. This also helps improve sleep quality."
              },
              {
                title: "Sleep Environment Check",
                description: "Ensure your mattress and pillow properly support your spine. Adjust pillows as needed for your sleeping position to maintain neutral spine alignment throughout the night."
              }
            ]}
          />
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Weekly Spine Maintenance</h2>
        <div className="bg-white rounded-lg shadow-md p-6">
          <p className="text-gray-700 mb-4">
            In addition to daily habits, incorporate these weekly practices:
          </p>
          
          <ul className="list-disc pl-6 space-y-3 text-gray-700">
            <li>
              <strong>Dedicated Exercise Sessions:</strong> Schedule 2-3 longer sessions (20-30 minutes) per week focused specifically on core strengthening and spine mobility exercises.
            </li>
            <li>
              <strong>Posture Self-Assessment:</strong> Once a week, take a photo of your posture from the side or have someone observe you. Check for forward head, rounded shoulders, or excessive lower back curve.
            </li>
            <li>
              <strong>Workspace Evaluation:</strong> Weekly, reassess your workspace ergonomics and make adjustments as needed. Ensure your chair, desk, and monitor are still properly positioned.
            </li>
            <li>
              <strong>Active Recovery:</strong> Incorporate one longer, low-intensity activity like walking, swimming, or gentle yoga to promote blood flow and mobility without strain.
            </li>
            <li>
              <strong>Relaxation Practice:</strong> Dedicate time to stress reduction through meditation, deep breathing, or progressive muscle relaxation to reduce muscle tension that affects the spine.
            </li>
            <li>
              <strong>Review and Adjust:</strong> Take a few minutes to reflect on how your spine felt during the week. Identify activities or positions that caused discomfort and plan modifications.
            </li>
          </ul>
        </div>
      </section>
      
      <div className="flex justify-between mt-12">
        <Link href="/modules/spine-flexibility" className="bg-gray-100 hover:bg-gray-200 text-gray-800 py-2 px-4 rounded-md transition-colors">
          Previous: Spine Flexibility
        </Link>
        <Link href="/modules/spine-friendly-lifestyle" className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors">
          Next Module: Spine-Friendly Lifestyle
        </Link>
      </div>
    </div>
  );
}
