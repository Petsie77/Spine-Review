import React from "react";
import Link from "next/link";
import ModuleProgress from "@/components/ui/module-progress";
import StepByStepGuide from "@/components/ui/step-by-step-guide";
import AnimationPlayer from "@/components/exercises/animation-player";

export default function UnderstandingSpinePage() {
  return (
    <div>
      <ModuleProgress 
        totalSections={5} 
        completedSections={0} 
        moduleTitle="Understanding Your Spine" 
      />
      
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-blue-700 mb-4">Understanding Your Spine</h1>
        <p className="text-gray-600">
          Learn about the structure and function of your spine, and why proper spine care is essential for overall health.
        </p>
      </header>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Spine Anatomy</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            Your spine, also called the vertebral column or backbone, is a complex structure made up of:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
            <li><strong>Vertebrae:</strong> 33 individual bones stacked on top of each other</li>
            <li><strong>Intervertebral discs:</strong> Cushion-like structures between vertebrae that absorb shock</li>
            <li><strong>Facet joints:</strong> Allow for movement between vertebrae</li>
            <li><strong>Spinal cord:</strong> The main pathway for messages between your brain and body</li>
            <li><strong>Spinal nerves:</strong> Branch off from the spinal cord and extend to various parts of the body</li>
            <li><strong>Muscles and ligaments:</strong> Provide support and enable movement</li>
          </ul>
          <p className="text-gray-700 mb-4">
            The spine is divided into five regions:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li><strong>Cervical (neck):</strong> 7 vertebrae (C1-C7)</li>
            <li><strong>Thoracic (mid-back):</strong> 12 vertebrae (T1-T12)</li>
            <li><strong>Lumbar (lower back):</strong> 5 vertebrae (L1-L5)</li>
            <li><strong>Sacral:</strong> 5 fused vertebrae forming the sacrum</li>
            <li><strong>Coccygeal:</strong> 4 fused vertebrae forming the tailbone (coccyx)</li>
          </ul>
        </div>
        
        <AnimationPlayer
          animationUrl="https://assets9.lottiefiles.com/packages/lf20_5njp3vgg.json"
          title="Spine Anatomy"
          description="The structure of the human spine showing vertebrae, discs, and spinal cord."
        />
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Natural Spine Curves</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            A healthy spine has three natural curves when viewed from the side:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
            <li><strong>Cervical lordosis:</strong> A slight inward curve in the neck</li>
            <li><strong>Thoracic kyphosis:</strong> A slight outward curve in the mid-back</li>
            <li><strong>Lumbar lordosis:</strong> A slight inward curve in the lower back</li>
          </ul>
          <p className="text-gray-700 mb-4">
            These curves are important because they:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li>Help maintain balance</li>
            <li>Absorb shock during movement</li>
            <li>Protect the spine from injury</li>
            <li>Allow for range of motion</li>
            <li>Distribute mechanical stress</li>
          </ul>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Spine Function</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            Your spine serves several critical functions:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li><strong>Support:</strong> Holds up your head, shoulders, and upper body</li>
            <li><strong>Movement:</strong> Enables bending, twisting, and flexibility</li>
            <li><strong>Protection:</strong> Shields the spinal cord from injury</li>
            <li><strong>Nerve function:</strong> Houses the pathway for nerve signals between brain and body</li>
            <li><strong>Shock absorption:</strong> Cushions impact during walking, running, and jumping</li>
          </ul>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Common Spine Problems</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            Understanding common spine issues can help you take preventive measures:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li><strong>Poor posture:</strong> Can lead to muscle imbalances and strain</li>
            <li><strong>Muscle tension:</strong> Often caused by stress, poor ergonomics, or overuse</li>
            <li><strong>Herniated discs:</strong> When the soft center of a disc pushes through a crack in the tougher exterior</li>
            <li><strong>Spinal stenosis:</strong> Narrowing of spaces within the spine, which can put pressure on nerves</li>
            <li><strong>Sciatica:</strong> Pain that radiates along the sciatic nerve from the lower back to the legs</li>
            <li><strong>Scoliosis:</strong> Abnormal lateral curvature of the spine</li>
          </ul>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">The Importance of Spine Health</h2>
        <StepByStepGuide
          title="Why Spine Care Matters"
          steps={[
            {
              title: "Pain Prevention",
              description: "Proper spine care helps prevent acute and chronic pain that can significantly impact quality of life."
            },
            {
              title: "Mobility Preservation",
              description: "A healthy spine allows for full range of motion and flexibility throughout life."
            },
            {
              title: "Nervous System Function",
              description: "The spine protects the spinal cord, which is essential for communication between your brain and body."
            },
            {
              title: "Overall Health",
              description: "Spine health affects posture, breathing, digestion, and even mood and energy levels."
            },
            {
              title: "Independence",
              description: "Maintaining spine health helps preserve independence and ability to perform daily activities as you age."
            }
          ]}
        />
      </section>
      
      <div className="flex justify-between mt-12">
        <Link href="/modules" className="bg-gray-100 hover:bg-gray-200 text-gray-800 py-2 px-4 rounded-md transition-colors">
          Back to Modules
        </Link>
        <Link href="/modules/proper-posture" className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors">
          Next Module: Proper Posture
        </Link>
      </div>
    </div>
  );
}
