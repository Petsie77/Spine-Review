import React from "react";
import Link from "next/link";
import ModuleProgress from "@/components/ui/module-progress";
import StepByStepGuide from "@/components/ui/step-by-step-guide";

export default function TrackingProgressPage() {
  return (
    <div>
      <ModuleProgress 
        totalSections={4} 
        completedSections={0} 
        moduleTitle="Tracking & Progress" 
      />
      
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-blue-700 mb-4">Tracking & Progress</h1>
        <p className="text-gray-600">
          Learn how to monitor your spine health journey, track improvements, and stay motivated with measurable goals.
        </p>
      </header>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Why Track Your Progress</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            Tracking your spine health journey offers several benefits:
          </p>
          
          <ul className="list-disc pl-6 space-y-3 text-gray-700">
            <li>
              <strong>Provides objective feedback</strong> on what's working and what needs adjustment
            </li>
            <li>
              <strong>Increases motivation</strong> by making small improvements visible over time
            </li>
            <li>
              <strong>Helps identify patterns</strong> in activities or habits that affect your spine
            </li>
            <li>
              <strong>Creates accountability</strong> to maintain consistent spine care practices
            </li>
            <li>
              <strong>Enables better communication</strong> with healthcare providers about your progress
            </li>
            <li>
              <strong>Provides encouragement</strong> during plateaus or setbacks in your journey
            </li>
          </ul>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">What to Track</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            Consider tracking these aspects of your spine health:
          </p>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-gray-800 mb-2">Pain and Discomfort</h3>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>Pain intensity (0-10 scale)</li>
                <li>Pain location and patterns</li>
                <li>Activities that increase or decrease pain</li>
                <li>Time of day when pain is better or worse</li>
                <li>Duration of pain episodes</li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-gray-800 mb-2">Mobility and Function</h3>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>Range of motion in different directions</li>
                <li>Ability to perform daily activities</li>
                <li>Exercise capacity and endurance</li>
                <li>Posture improvements</li>
                <li>Balance and coordination</li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-gray-800 mb-2">Habits and Practices</h3>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>Consistency with exercises and stretches</li>
                <li>Posture check-ins throughout the day</li>
                <li>Ergonomic adjustments made</li>
                <li>Movement breaks taken</li>
                <li>Sleep quality and position</li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-gray-800 mb-2">Lifestyle Factors</h3>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>Stress levels and management techniques used</li>
                <li>Hydration and nutrition choices</li>
                <li>Physical activity levels</li>
                <li>Screen time and device usage</li>
                <li>Environmental factors affecting your spine</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Tracking Methods</h2>
        
        <StepByStepGuide
          title="Effective Ways to Track Your Progress"
          steps={[
            {
              title: "Daily Journal",
              description: "Keep a simple daily log of pain levels, activities, and spine care practices. Note patterns and triggers that affect how your spine feels. A few minutes of journaling each day can reveal valuable insights over time."
            },
            {
              title: "Photo Documentation",
              description: "Take regular photos of your posture (front and side view) to visually track changes. Use consistent positioning and clothing to make comparisons easier. Review photos monthly to observe gradual improvements."
            },
            {
              title: "Mobility Measurements",
              description: "Periodically measure your range of motion in different directions. Simple tests include how far you can bend forward, twist to each side, or look over your shoulder. Record measurements to track improvements."
            },
            {
              title: "Functional Milestones",
              description: "Track your ability to perform specific activities that were previously difficult or painful. Examples might include sitting comfortably for longer periods, carrying groceries without pain, or participating in physical activities."
            },
            {
              title: "Digital Apps",
              description: "Use health tracking apps to monitor exercise consistency, pain levels, and other metrics. Many apps allow you to export data to share with healthcare providers or review long-term trends."
            }
          ]}
        />
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Setting SMART Goals</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            Effective spine health goals follow the SMART framework:
          </p>
          
          <ul className="list-disc pl-6 space-y-3 text-gray-700 mb-6">
            <li>
              <strong>Specific:</strong> Clearly define what you want to achieve (e.g., "Perform core strengthening exercises 3 times per week" rather than "Exercise more")
            </li>
            <li>
              <strong>Measurable:</strong> Include metrics to track progress (e.g., "Hold plank position for 30 seconds" rather than "Get stronger")
            </li>
            <li>
              <strong>Achievable:</strong> Set realistic goals based on your current abilities and circumstances
            </li>
            <li>
              <strong>Relevant:</strong> Choose goals that directly support your spine health priorities
            </li>
            <li>
              <strong>Time-bound:</strong> Set deadlines or timeframes for achieving your goals
            </li>
          </ul>
          
          <p className="text-gray-700 mb-4">
            Examples of SMART spine health goals:
          </p>
          
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li>"Complete a 5-minute spine mobility routine every morning for the next 30 days"</li>
            <li>"Reduce sitting time to maximum 45-minute intervals before taking a movement break for the next week"</li>
            <li>"Increase walking distance from current 15 minutes to 30 minutes without back pain within 6 weeks"</li>
            <li>"Perform the core exercise routine from Module 6 three times weekly for the next month"</li>
            <li>"Set up an ergonomic workstation according to Module 3 guidelines by this weekend"</li>
          </ul>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Staying Motivated</h2>
        <div className="bg-white rounded-lg shadow-md p-6">
          <p className="text-gray-700 mb-4">
            Maintain motivation on your spine health journey with these strategies:
          </p>
          
          <ul className="list-disc pl-6 space-y-3 text-gray-700">
            <li>
              <strong>Celebrate small wins</strong> - Acknowledge and reward yourself for consistent efforts and improvements
            </li>
            <li>
              <strong>Find an accountability partner</strong> - Share your goals with someone who can check in on your progress
            </li>
            <li>
              <strong>Focus on how you feel</strong> - Notice improvements in comfort, energy, and quality of life, not just physical measurements
            </li>
            <li>
              <strong>Create visual reminders</strong> - Use charts, calendars, or progress photos to visualize your journey
            </li>
            <li>
              <strong>Connect with community</strong> - Join online or in-person groups focused on spine health or movement
            </li>
            <li>
              <strong>Adjust expectations</strong> - Remember that progress isn't always linear; some days will be better than others
            </li>
            <li>
              <strong>Revisit your why</strong> - Regularly remind yourself of the personal reasons behind your spine health journey
            </li>
          </ul>
        </div>
      </section>
      
      <div className="flex justify-between mt-12">
        <Link href="/modules/spine-friendly-lifestyle" className="bg-gray-100 hover:bg-gray-200 text-gray-800 py-2 px-4 rounded-md transition-colors">
          Previous: Spine-Friendly Lifestyle
        </Link>
        <Link href="/modules" className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors">
          Back to All Modules
        </Link>
      </div>
    </div>
  );
}
