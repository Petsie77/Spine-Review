import React from "react";
import Link from "next/link";
import ModuleProgress from "@/components/ui/module-progress";
import PostureComparison from "@/components/posture/posture-comparison";
import VideoPlayer from "@/components/exercises/video-player";

export default function StandingWalkingPage() {
  return (
    <div>
      <ModuleProgress 
        totalSections={4} 
        completedSections={0} 
        moduleTitle="Standing & Walking Posture" 
      />
      
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-blue-700 mb-4">Standing & Walking Posture</h1>
        <p className="text-gray-600">
          Learn how to maintain proper alignment while standing and walking to reduce strain on your spine and prevent pain.
        </p>
      </header>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Proper Standing Posture</h2>
        
        <PostureComparison
          title="Standing Alignment"
          correctImageUrl="/images/correct-standing.jpg"
          incorrectImageUrl="/images/incorrect-standing.jpg"
          correctDescription="Head balanced over shoulders, shoulders relaxed and back, neutral spine curves maintained, knees slightly bent, weight evenly distributed on both feet."
          incorrectDescription="Head forward, rounded shoulders, exaggerated lower back curve, locked knees, weight shifted to one side."
          tips={[
            "Stand with feet hip-width apart for a stable base",
            "Distribute weight evenly between both feet",
            "Keep knees slightly soft, not locked",
            "Engage your core muscles gently",
            "Roll shoulders back and down, away from ears",
            "Imagine a string pulling the top of your head toward the ceiling",
            "Tuck chin slightly to align ears with shoulders"
          ]}
        />
        
        <div className="bg-white rounded-lg shadow-md p-6 mt-6">
          <h3 className="text-xl font-semibold text-gray-800 mb-3">Common Standing Posture Mistakes</h3>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li><strong>Leaning on one leg</strong> - creates imbalance in hips and spine</li>
            <li><strong>Locking knees</strong> - increases strain on joints and lower back</li>
            <li><strong>Forward head posture</strong> - strains neck and upper back muscles</li>
            <li><strong>Rounded shoulders</strong> - leads to upper back pain and restricted breathing</li>
            <li><strong>Excessive lower back arch</strong> - compresses spinal structures</li>
            <li><strong>Protruding abdomen</strong> - weakens core and increases lower back strain</li>
          </ul>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Standing for Long Periods</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            If your job or activities require prolonged standing, try these strategies to reduce spine strain:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li><strong>Shift weight</strong> frequently between feet, but avoid leaning to one side</li>
            <li><strong>Use a small footrest</strong> to alternate lifting one foot slightly</li>
            <li><strong>Stand on a cushioned mat</strong> to reduce impact on joints</li>
            <li><strong>Take mini-breaks</strong> to move around every 20-30 minutes</li>
            <li><strong>Wear supportive shoes</strong> with good arch support and cushioning</li>
            <li><strong>Position work</strong> at elbow height to avoid bending forward</li>
            <li><strong>Do gentle stretches</strong> during breaks (calf raises, shoulder rolls, gentle backbends)</li>
          </ul>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Walking with Proper Posture</h2>
        
        <VideoPlayer
          videoUrl="https://www.youtube.com/embed/OyK0oE5rwFY"
          title="Proper Walking Technique for Spine Health"
          description="Learn how to walk with alignment that supports your spine and reduces strain."
        />
        
        <div className="bg-white rounded-lg shadow-md p-6 mt-6">
          <h3 className="text-xl font-semibold text-gray-800 mb-3">Elements of Healthy Walking Posture</h3>
          <ul className="list-disc pl-6 space-y-3 text-gray-700">
            <li>
              <strong>Head position:</strong> Keep your head up with gaze forward, chin parallel to the ground. 
              Avoid looking down at your feet or phone while walking.
            </li>
            <li>
              <strong>Shoulder alignment:</strong> Keep shoulders relaxed, back, and down. 
              Avoid hunching or tensing shoulders during movement.
            </li>
            <li>
              <strong>Arm movement:</strong> Allow arms to swing naturally at your sides with elbows bent at about 90 degrees. 
              This counterbalances your leg movement and helps maintain stability.
            </li>
            <li>
              <strong>Core engagement:</strong> Maintain gentle core activation to support your spine. 
              Think of drawing your navel slightly toward your spine.
            </li>
            <li>
              <strong>Hip movement:</strong> Let your hips move naturally with each step, but avoid excessive side-to-side swaying.
            </li>
            <li>
              <strong>Foot placement:</strong> Strike the ground with your heel first, then roll through to push off with your toes. 
              Take steps of comfortable length - not too long or short.
            </li>
            <li>
              <strong>Breathing:</strong> Breathe deeply and naturally while walking. Proper breathing helps maintain good posture 
              and provides oxygen to working muscles.
            </li>
          </ul>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Footwear Considerations</h2>
        <div className="bg-white rounded-lg shadow-md p-6">
          <p className="text-gray-700 mb-4">
            Your choice of footwear significantly impacts your standing and walking posture:
          </p>
          <ul className="list-disc pl-6 space-y-3 text-gray-700">
            <li>
              <strong>Supportive shoes:</strong> Look for shoes with good arch support, cushioning, and a slightly raised heel 
              (about 1/4 to 1/2 inch). The shoe should bend at the ball of the foot, not in the middle.
            </li>
            <li>
              <strong>Proper fit:</strong> Ensure adequate toe room and a snug (not tight) fit around the heel and midfoot. 
              Shoes that are too loose or tight can alter your gait.
            </li>
            <li>
              <strong>High heels:</strong> Limit time in heels over 2 inches, as they shift your center of gravity forward, 
              increasing lower back curve and strain. If you must wear heels, bring supportive shoes to change into when possible.
            </li>
            <li>
              <strong>Completely flat shoes:</strong> Shoes with no cushioning or support (like many flip-flops or ballet flats) 
              provide minimal shock absorption and can lead to foot, knee, and back pain with prolonged use.
            </li>
            <li>
              <strong>Replace worn shoes:</strong> Shoes with uneven wear patterns can affect alignment. Replace walking/running 
              shoes every 300-500 miles or when you notice significant wear.
            </li>
            <li>
              <strong>Consider orthotics:</strong> If you have specific foot issues (flat feet, high arches), custom or over-the-counter 
              orthotics can help maintain proper alignment.
            </li>
          </ul>
        </div>
      </section>
      
      <div className="flex justify-between mt-12">
        <Link href="/modules/sitting-ergonomics" className="bg-gray-100 hover:bg-gray-200 text-gray-800 py-2 px-4 rounded-md transition-colors">
          Previous: Sitting Ergonomics
        </Link>
        <Link href="/modules/sleeping-posture" className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors">
          Next Module: Sleeping Posture
        </Link>
      </div>
    </div>
  );
}
