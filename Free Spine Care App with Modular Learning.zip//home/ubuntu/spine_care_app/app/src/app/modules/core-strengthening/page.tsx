import React from "react";
import Link from "next/link";
import ModuleProgress from "@/components/ui/module-progress";
import ExerciseCard from "@/components/exercises/exercise-card";
import VideoPlayer from "@/components/exercises/video-player";

export default function CoreStrengtheningPage() {
  return (
    <div>
      <ModuleProgress 
        totalSections={4} 
        completedSections={0} 
        moduleTitle="Core Strengthening Exercises" 
      />
      
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-blue-700 mb-4">Core Strengthening Exercises</h1>
        <p className="text-gray-600">
          Build a strong foundation to support your spine with these targeted core exercises.
          A strong core is essential for spine health and proper posture.
        </p>
      </header>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Why Core Strength Matters</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            Your core muscles form a supportive cylinder around your spine and pelvis. These muscles include:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
            <li><strong>Transverse abdominis:</strong> Your deepest abdominal muscle that wraps around your spine and organs</li>
            <li><strong>Multifidus:</strong> Deep back muscles that run along your spine</li>
            <li><strong>Diaphragm:</strong> Your primary breathing muscle at the top of the cylinder</li>
            <li><strong>Pelvic floor:</strong> The muscles that form the bottom of the cylinder</li>
            <li><strong>Obliques:</strong> Side abdominal muscles that help with rotation and side-bending</li>
            <li><strong>Rectus abdominis:</strong> The "six-pack" muscles in the front</li>
          </ul>
          <p className="text-gray-700 mb-4">
            A strong core:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li>Stabilizes your spine during movement</li>
            <li>Improves posture and alignment</li>
            <li>Reduces strain on spinal structures</li>
            <li>Helps prevent and manage back pain</li>
            <li>Improves balance and coordination</li>
            <li>Enhances performance in daily activities and exercise</li>
          </ul>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Core Exercise Demonstration</h2>
        
        <VideoPlayer
          videoUrl="https://www.youtube.com/embed/DxIeqiyYZkQ"
          title="9-Minute Core Workout for a Healthy Spine"
          description="Follow along with this gentle yet effective core workout designed specifically for spine health."
        />
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Recommended Exercises</h2>
        <p className="text-gray-600 mb-6">
          Start with these beginner-friendly exercises and progress as your strength improves.
          Always focus on proper form rather than repetitions.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <ExerciseCard
            title="Bird Dog"
            description="Stabilizes your spine while moving your limbs, engaging deep core muscles."
            imageUrl="/images/bird-dog.jpg"
            difficulty="beginner"
            targetAreas={["Transverse abdominis", "Multifidus", "Glutes"]}
            duration="2-3 sets of 8-12 reps each side"
          />
          
          <ExerciseCard
            title="Modified Plank"
            description="Builds endurance in your core stabilizing muscles with less stress on the spine."
            imageUrl="/images/modified-plank.jpg"
            difficulty="beginner"
            targetAreas={["Transverse abdominis", "Obliques", "Shoulders"]}
            duration="3 sets of 15-30 seconds"
          />
          
          <ExerciseCard
            title="Glute Bridge"
            description="Strengthens glutes and core while promoting proper pelvic alignment."
            imageUrl="/images/glute-bridge.jpg"
            difficulty="beginner"
            targetAreas={["Glutes", "Lower back", "Hamstrings"]}
            duration="2-3 sets of 10-15 reps"
          />
          
          <ExerciseCard
            title="Dead Bug"
            description="Teaches core stability while moving limbs, with minimal spine stress."
            imageUrl="/images/dead-bug.jpg"
            difficulty="beginner"
            targetAreas={["Transverse abdominis", "Rectus abdominis", "Hip flexors"]}
            duration="2-3 sets of 8-10 reps each side"
          />
          
          <ExerciseCard
            title="Cat-Cow"
            description="Improves spine mobility while gently engaging core muscles."
            imageUrl="/images/cat-cow.jpg"
            difficulty="beginner"
            targetAreas={["Spine mobility", "Abdominals", "Back muscles"]}
            duration="10-12 slow repetitions"
          />
          
          <ExerciseCard
            title="Side-Lying Leg Lift"
            description="Targets lateral core muscles and hip stabilizers."
            imageUrl="/images/side-leg-lift.jpg"
            difficulty="beginner"
            targetAreas={["Obliques", "Hip abductors", "Quadratus lumborum"]}
            duration="2 sets of 10-12 reps each side"
          />
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Exercise Guidelines</h2>
        <div className="bg-white rounded-lg shadow-md p-6">
          <ul className="list-disc pl-6 space-y-3 text-gray-700">
            <li><strong>Start slowly</strong> and focus on proper form rather than repetitions</li>
            <li><strong>Breathe normally</strong> during exercises; avoid holding your breath</li>
            <li><strong>Engage your core gently</strong> - imagine drawing your navel toward your spine</li>
            <li><strong>Stop if you feel pain</strong> (discomfort is normal, pain is not)</li>
            <li><strong>Consistency is key</strong> - aim for 2-3 core sessions per week</li>
            <li><strong>Progress gradually</strong> by increasing duration before increasing intensity</li>
            <li><strong>Consult a healthcare professional</strong> before starting if you have existing back issues</li>
          </ul>
        </div>
      </section>
      
      <div className="flex justify-between mt-12">
        <Link href="/modules" className="bg-gray-100 hover:bg-gray-200 text-gray-800 py-2 px-4 rounded-md transition-colors">
          Back to Modules
        </Link>
        <Link href="/modules/spine-flexibility" className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors">
          Next Module: Spine Flexibility
        </Link>
      </div>
    </div>
  );
}
