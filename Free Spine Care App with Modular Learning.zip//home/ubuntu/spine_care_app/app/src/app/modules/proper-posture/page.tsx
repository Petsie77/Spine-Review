import React from "react";
import Link from "next/link";
import ModuleProgress from "@/components/ui/module-progress";
import VideoPlayer from "@/components/exercises/video-player";
import PostureComparison from "@/components/posture/posture-comparison";

export default function ProperPosturePage() {
  return (
    <div>
      <ModuleProgress 
        totalSections={5} 
        completedSections={0} 
        moduleTitle="Proper Posture Fundamentals" 
      />
      
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-blue-700 mb-4">Proper Posture Fundamentals</h1>
        <p className="text-gray-600">
          Learn the basics of good posture and how it affects your spine health. This module covers
          the principles of proper alignment and techniques to improve your posture.
        </p>
      </header>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Why Posture Matters</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            Good posture is essential for spine health. When your body is properly aligned, the stress on your spine
            is minimized, reducing the risk of pain and injury. Poor posture, on the other hand, can lead to:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
            <li>Muscle strain and fatigue</li>
            <li>Joint wear and tear</li>
            <li>Spinal misalignment</li>
            <li>Reduced flexibility and mobility</li>
            <li>Increased risk of injury</li>
            <li>Digestive and breathing problems</li>
          </ul>
          <p className="text-gray-700">
            By maintaining good posture, you can prevent these issues and improve your overall health and well-being.
          </p>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Principles of Good Posture</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            Good posture follows these key principles:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
            <li><strong>Neutral spine:</strong> Maintain the natural curves of your spine</li>
            <li><strong>Balanced weight:</strong> Distribute your weight evenly</li>
            <li><strong>Relaxed muscles:</strong> Avoid unnecessary tension</li>
            <li><strong>Aligned joints:</strong> Keep your joints in their optimal position</li>
            <li><strong>Minimal strain:</strong> Use the least amount of muscular effort</li>
          </ul>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Standing Posture</h2>
        
        <PostureComparison
          title="Standing Posture"
          correctImageUrl="/images/correct-standing.jpg"
          incorrectImageUrl="/images/incorrect-standing.jpg"
          correctDescription="Head balanced over shoulders, shoulders back and relaxed, neutral spine, knees slightly bent, weight evenly distributed on both feet."
          incorrectDescription="Head forward, rounded shoulders, arched lower back, locked knees, weight shifted to one side."
          tips={[
            "Stand with feet hip-width apart",
            "Keep your weight balanced on the balls and heels of your feet",
            "Tuck your chin slightly to align your head with your spine",
            "Pull your shoulders back and down",
            "Engage your core muscles lightly",
            "Keep your knees slightly bent, not locked"
          ]}
        />
        
        <VideoPlayer
          videoUrl="https://www.youtube.com/embed/OyK0oE5rwFY"
          title="How to Improve Your Standing Posture"
          description="This video demonstrates exercises and techniques to improve your standing posture."
        />
      </section>
      
      <div className="flex justify-between mt-12">
        <Link href="/modules" className="bg-gray-100 hover:bg-gray-200 text-gray-800 py-2 px-4 rounded-md transition-colors">
          Back to Modules
        </Link>
        <Link href="/modules/sitting-ergonomics" className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors">
          Next Module: Sitting Ergonomics
        </Link>
      </div>
    </div>
  );
}
