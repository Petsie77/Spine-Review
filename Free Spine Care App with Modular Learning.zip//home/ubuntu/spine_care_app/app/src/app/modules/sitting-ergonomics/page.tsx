import React from "react";
import Link from "next/link";
import ModuleProgress from "@/components/ui/module-progress";
import VideoPlayer from "@/components/exercises/video-player";
import StepByStepGuide from "@/components/ui/step-by-step-guide";

export default function SittingErgonomicsPage() {
  return (
    <div>
      <ModuleProgress 
        totalSections={5} 
        completedSections={0} 
        moduleTitle="Sitting Posture & Ergonomics" 
      />
      
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-blue-700 mb-4">Sitting Posture & Ergonomics</h1>
        <p className="text-gray-600">
          Learn how to set up your workspace and maintain proper sitting posture to prevent spine strain and discomfort.
        </p>
      </header>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">The Impact of Prolonged Sitting</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            Modern life often involves spending hours sitting at desks, in cars, or on couches. Extended sitting can lead to:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
            <li>Increased pressure on spinal discs</li>
            <li>Muscle imbalances and weakness</li>
            <li>Reduced circulation</li>
            <li>Stiffness and decreased mobility</li>
            <li>Poor posture habits that transfer to other activities</li>
          </ul>
          <p className="text-gray-700 mb-4">
            While it's best to limit sitting time and take regular movement breaks, proper ergonomics can significantly 
            reduce the negative effects when you do need to sit.
          </p>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Ergonomic Workspace Setup</h2>
        
        <StepByStepGuide
          title="Setting Up Your Workspace"
          steps={[
            {
              title: "Chair Height",
              description: "Adjust your chair height so your feet rest flat on the floor and your knees are level with or slightly lower than your hips."
            },
            {
              title: "Chair Support",
              description: "Your chair should support the natural curve of your lower back. Use a small pillow or rolled towel if needed."
            },
            {
              title: "Monitor Position",
              description: "Position your monitor at eye level, about an arm's length away. The top of the screen should be at or slightly below eye level."
            },
            {
              title: "Keyboard and Mouse",
              description: "Place your keyboard and mouse at a height that allows your elbows to bend at about 90 degrees, with your arms close to your body."
            },
            {
              title: "Desk Arrangement",
              description: "Keep frequently used items within easy reach to avoid stretching or twisting."
            }
          ]}
        />
        
        <VideoPlayer
          videoUrl="https://www.youtube.com/embed/F8_ME4VwTiw"
          title="Office Ergonomics: Simple Solutions for Comfort and Safety"
          description="Learn how to set up your workspace to minimize strain on your spine and prevent discomfort."
        />
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Proper Sitting Technique</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            Even with the perfect ergonomic setup, how you sit matters. Follow these guidelines:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
            <li><strong>Sit back in your chair</strong> with your back against the backrest</li>
            <li><strong>Keep your shoulders relaxed</strong>, not hunched or rounded forward</li>
            <li><strong>Position your head directly above your shoulders</strong>, not jutting forward</li>
            <li><strong>Maintain a small gap</strong> between the back of your knees and the edge of your chair</li>
            <li><strong>Keep your elbows close to your body</strong>, bent at about 90 degrees</li>
            <li><strong>Avoid crossing your legs</strong> for extended periods</li>
          </ul>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Movement Breaks</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            No matter how perfect your sitting posture, your body needs regular movement. Try to:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
            <li>Stand up and move around for 1-2 minutes every 30 minutes</li>
            <li>Stretch your neck, shoulders, and back during these breaks</li>
            <li>Consider a sit-stand desk to alternate between sitting and standing</li>
            <li>Use the 20-20-20 rule for eye strain: every 20 minutes, look at something 20 feet away for 20 seconds</li>
          </ul>
        </div>
      </section>
      
      <div className="flex justify-between mt-12">
        <Link href="/modules/proper-posture" className="bg-gray-100 hover:bg-gray-200 text-gray-800 py-2 px-4 rounded-md transition-colors">
          Previous: Proper Posture
        </Link>
        <Link href="/modules/standing-walking" className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors">
          Next: Standing & Walking
        </Link>
      </div>
    </div>
  );
}
