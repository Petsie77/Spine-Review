import React from "react";
import Link from "next/link";
import ModuleProgress from "@/components/ui/module-progress";
import StepByStepGuide from "@/components/ui/step-by-step-guide";

export default function SpineFriendlyLifestylePage() {
  return (
    <div>
      <ModuleProgress 
        totalSections={5} 
        completedSections={0} 
        moduleTitle="Spine-Friendly Lifestyle" 
      />
      
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-blue-700 mb-4">Spine-Friendly Lifestyle</h1>
        <p className="text-gray-600">
          Learn how to make choices in your daily life that support long-term spine health and prevent problems.
        </p>
      </header>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Nutrition for Spine Health</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            What you eat affects your spine health in several ways:
          </p>
          
          <ul className="list-disc pl-6 space-y-3 text-gray-700 mb-4">
            <li>
              <strong>Anti-inflammatory foods</strong> can help reduce pain and inflammation around the spine. 
              Include fatty fish (salmon, mackerel), berries, leafy greens, nuts, and olive oil in your diet.
            </li>
            <li>
              <strong>Calcium and vitamin D</strong> are essential for bone health, including your vertebrae. 
              Sources include dairy products, fortified plant milks, leafy greens, and moderate sun exposure.
            </li>
            <li>
              <strong>Magnesium</strong> helps maintain muscle and nerve function. Find it in nuts, seeds, 
              whole grains, and leafy vegetables.
            </li>
            <li>
              <strong>Collagen-supporting nutrients</strong> like vitamin C help maintain the health of discs, 
              ligaments, and tendons. Citrus fruits, berries, and colorful vegetables are good sources.
            </li>
            <li>
              <strong>Adequate hydration</strong> is crucial for spinal disc health. Aim for 8-10 glasses of water daily, 
              more if you're active or in hot weather.
            </li>
            <li>
              <strong>Weight management</strong> through balanced nutrition reduces strain on the spine. 
              Extra weight, especially around the midsection, can pull the spine out of alignment.
            </li>
          </ul>
          
          <p className="text-gray-700">
            Foods to limit for spine health include highly processed foods, sugary items, and excessive alcohol, 
            which can increase inflammation and interfere with nutrient absorption.
          </p>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Physical Activity Balance</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            A balanced approach to physical activity supports spine health:
          </p>
          
          <StepByStepGuide
            title="Creating a Balanced Activity Plan"
            steps={[
              {
                title: "Cardiovascular Exercise",
                description: "Include 150 minutes of moderate-intensity activity weekly (like walking, swimming, or cycling) to improve circulation to spinal structures and support overall health. Choose spine-friendly options that don't jar or compress the spine."
              },
              {
                title: "Strength Training",
                description: "Perform strength exercises 2-3 times weekly, focusing on core, back, and hip muscles that support the spine. Include exercises for all major muscle groups to maintain balance around the spine."
              },
              {
                title: "Flexibility Work",
                description: "Dedicate time to stretching and mobility exercises 3-5 days per week. Focus on areas that tend to get tight from daily activities, like hip flexors, chest, and hamstrings."
              },
              {
                title: "Skill-Based Movement",
                description: "Consider activities like yoga, Pilates, or tai chi that combine strength, flexibility, and body awareness to improve posture and movement patterns."
              },
              {
                title: "Rest and Recovery",
                description: "Allow adequate recovery between intense workouts. Listen to your body and distinguish between productive discomfort and potential injury signals."
              }
            ]}
          />
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Stress Management</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            Chronic stress directly impacts spine health through:
          </p>
          
          <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
            <li>Increased muscle tension, especially in the neck, shoulders, and back</li>
            <li>Shallow breathing patterns that reduce mobility in the ribcage and thoracic spine</li>
            <li>Poor sleep quality, which impairs tissue repair and pain regulation</li>
            <li>Reduced body awareness, leading to poor posture and movement habits</li>
            <li>Heightened pain sensitivity and reduced pain tolerance</li>
          </ul>
          
          <p className="text-gray-700 mb-4">
            Effective stress management techniques for spine health include:
          </p>
          
          <ul className="list-disc pl-6 space-y-3 text-gray-700">
            <li>
              <strong>Mindfulness meditation:</strong> Even 5-10 minutes daily can reduce muscle tension and improve body awareness.
            </li>
            <li>
              <strong>Deep breathing:</strong> Practice diaphragmatic breathing several times daily to release tension and improve thoracic mobility.
            </li>
            <li>
              <strong>Progressive muscle relaxation:</strong> Systematically tense and release muscle groups to identify and release chronic tension.
            </li>
            <li>
              <strong>Time in nature:</strong> Regular exposure to natural environments reduces stress hormones and promotes relaxation.
            </li>
            <li>
              <strong>Creative activities:</strong> Engaging in art, music, or other creative pursuits can provide mental breaks from stressors.
            </li>
            <li>
              <strong>Social connection:</strong> Quality time with supportive people buffers against stress effects.
            </li>
          </ul>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Sleep Optimization</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            Beyond sleeping posture, these sleep habits support spine health:
          </p>
          
          <ul className="list-disc pl-6 space-y-3 text-gray-700">
            <li>
              <strong>Consistent schedule:</strong> Maintain regular sleep and wake times to support your body's natural rhythms.
            </li>
            <li>
              <strong>Adequate duration:</strong> Aim for 7-9 hours of quality sleep to allow for tissue repair and recovery.
            </li>
            <li>
              <strong>Sleep environment:</strong> Create a cool, dark, quiet room with a supportive mattress and pillows.
            </li>
            <li>
              <strong>Pre-sleep routine:</strong> Develop a calming routine that includes gentle stretching and relaxation techniques.
            </li>
            <li>
              <strong>Screen limitations:</strong> Reduce blue light exposure from devices at least 1 hour before bed.
            </li>
            <li>
              <strong>Mindful eating:</strong> Avoid heavy meals, caffeine, and alcohol close to bedtime.
            </li>
            <li>
              <strong>Morning movement:</strong> Begin your day with gentle mobility exercises to transition from sleep to activity.
            </li>
          </ul>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Spine-Friendly Environment</h2>
        <div className="bg-white rounded-lg shadow-md p-6">
          <p className="text-gray-700 mb-4">
            Create environments that support spine health:
          </p>
          
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-800 mb-2">Home Setup</h3>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li>Position frequently used items within easy reach to avoid overreaching or twisting</li>
              <li>Use step stools for high items rather than straining or extending</li>
              <li>Consider furniture height and depth for easy entry and exit</li>
              <li>Create dedicated spaces for movement and exercise</li>
              <li>Install adequate lighting to prevent hunching to see clearly</li>
            </ul>
          </div>
          
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-800 mb-2">Car Setup</h3>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li>Adjust your seat to maintain natural spine curves</li>
              <li>Position the seat close enough to reach pedals without stretching</li>
              <li>Use lumbar support if needed</li>
              <li>Take breaks every 1-2 hours on long drives</li>
              <li>Enter and exit carefully, avoiding twisting while bearing weight</li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-medium text-gray-800 mb-2">Technology Use</h3>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li>Hold phones at eye level rather than looking down</li>
              <li>Use speaker phone or headsets for long calls</li>
              <li>Position tablets on stands rather than holding them</li>
              <li>Take regular breaks from all devices</li>
              <li>Consider ergonomic accessories for frequently used technology</li>
            </ul>
          </div>
        </div>
      </section>
      
      <div className="flex justify-between mt-12">
        <Link href="/modules/daily-routines" className="bg-gray-100 hover:bg-gray-200 text-gray-800 py-2 px-4 rounded-md transition-colors">
          Previous: Daily Routines
        </Link>
        <Link href="/modules/tracking-progress" className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors">
          Next Module: Tracking & Progress
        </Link>
      </div>
    </div>
  );
}
