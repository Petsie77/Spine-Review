import React from "react";
import Link from "next/link";
import ModuleProgress from "@/components/ui/module-progress";
import PostureComparison from "@/components/posture/posture-comparison";
import VideoPlayer from "@/components/exercises/video-player";

export default function SpineFlexibilityPage() {
  return (
    <div>
      <ModuleProgress 
        totalSections={4} 
        completedSections={0} 
        moduleTitle="Spine Flexibility & Mobility" 
      />
      
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-blue-700 mb-4">Spine Flexibility & Mobility</h1>
        <p className="text-gray-600">
          Learn how to safely improve your spine's range of motion and reduce stiffness with targeted mobility exercises.
        </p>
      </header>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">The Importance of Spine Mobility</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            A flexible, mobile spine is essential for:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
            <li><strong>Everyday movements</strong> like bending, twisting, and reaching</li>
            <li><strong>Preventing stiffness and pain</strong> that can develop from limited movement</li>
            <li><strong>Maintaining proper posture</strong> and alignment</li>
            <li><strong>Reducing stress on spinal structures</strong> by distributing forces evenly</li>
            <li><strong>Supporting healthy aging</strong> and independence</li>
          </ul>
          <p className="text-gray-700 mb-4">
            As we age or become less active, our spine can lose mobility, leading to stiffness, discomfort, and increased risk of injury. 
            Regular mobility exercises can help maintain or improve your spine's range of motion.
          </p>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Spine Mobility Demonstration</h2>
        
        <VideoPlayer
          videoUrl="https://www.youtube.com/embed/n6Etl3x9AnU"
          title="Gentle Spine Mobility Routine"
          description="Follow along with this 10-minute routine designed to improve mobility in all regions of your spine."
        />
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Key Mobility Exercises</h2>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="text-gray-700 mb-4">
            These exercises target different movements of the spine:
          </p>
          
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-800 mb-2">1. Cat-Cow Stretch</h3>
            <p className="text-gray-700 mb-2">
              <strong>Benefits:</strong> Improves flexion and extension of the entire spine
            </p>
            <p className="text-gray-700 mb-2">
              <strong>How to perform:</strong> Start on hands and knees. Inhale as you drop your belly, lifting your head and tailbone (cow). 
              Exhale as you round your spine, tucking your chin and tailbone (cat). Move slowly between these positions.
            </p>
            <p className="text-gray-700">
              <strong>Frequency:</strong> 10-12 repetitions, 1-2 times daily
            </p>
          </div>
          
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-800 mb-2">2. Seated Spinal Rotation</h3>
            <p className="text-gray-700 mb-2">
              <strong>Benefits:</strong> Improves rotational mobility of the thoracic spine
            </p>
            <p className="text-gray-700 mb-2">
              <strong>How to perform:</strong> Sit on a chair with feet flat on the floor. Place your right hand on your left knee and left hand behind you. 
              Gently rotate to the left, looking over your left shoulder. Hold for 15-30 seconds, then repeat on the other side.
            </p>
            <p className="text-gray-700">
              <strong>Frequency:</strong> 3 repetitions each side, daily
            </p>
          </div>
          
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-800 mb-2">3. Child's Pose with Reach</h3>
            <p className="text-gray-700 mb-2">
              <strong>Benefits:</strong> Stretches the lower back and promotes shoulder mobility
            </p>
            <p className="text-gray-700 mb-2">
              <strong>How to perform:</strong> Start in child's pose with knees wide and arms extended forward. 
              Walk your hands to the right, feeling a stretch along the left side of your body. Hold for 15-30 seconds, 
              then walk your hands to the left.
            </p>
            <p className="text-gray-700">
              <strong>Frequency:</strong> 2-3 repetitions each side, daily
            </p>
          </div>
          
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-800 mb-2">4. Gentle Backbend</h3>
            <p className="text-gray-700 mb-2">
              <strong>Benefits:</strong> Improves extension of the spine, counteracts forward-leaning postures
            </p>
            <p className="text-gray-700 mb-2">
              <strong>How to perform:</strong> Stand with feet hip-width apart, hands on lower back for support. 
              Gently lean backward, looking up slightly. Only go as far as comfortable, keeping the movement in the mid-back.
            </p>
            <p className="text-gray-700">
              <strong>Frequency:</strong> 5-8 repetitions, holding each for 2-3 seconds, daily
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-medium text-gray-800 mb-2">5. Supine Spinal Twist</h3>
            <p className="text-gray-700 mb-2">
              <strong>Benefits:</strong> Releases tension in the lower back and improves rotation
            </p>
            <p className="text-gray-700 mb-2">
              <strong>How to perform:</strong> Lie on your back with knees bent. Drop both knees to the right while turning your head to the left. 
              Hold for 30-60 seconds, then switch sides.
            </p>
            <p className="text-gray-700">
              <strong>Frequency:</strong> 2-3 repetitions each side, daily
            </p>
          </div>
        </div>
      </section>
      
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-blue-600 mb-4">Safety Guidelines</h2>
        <div className="bg-white rounded-lg shadow-md p-6">
          <ul className="list-disc pl-6 space-y-3 text-gray-700">
            <li><strong>Move slowly and gently</strong> - mobility exercises should never be forced or painful</li>
            <li><strong>Focus on breathing</strong> - coordinate your breath with movement for better results</li>
            <li><strong>Warm up first</strong> - perform mobility exercises after a brief warm-up like walking</li>
            <li><strong>Stay within your range</strong> - never push into pain, only mild stretch sensations</li>
            <li><strong>Be consistent</strong> - daily practice yields better results than occasional intense sessions</li>
            <li><strong>Progress gradually</strong> - increase range of motion slowly over time</li>
            <li><strong>Consult a professional</strong> if you have existing spine conditions or pain</li>
          </ul>
        </div>
      </section>
      
      <div className="flex justify-between mt-12">
        <Link href="/modules/core-strengthening" className="bg-gray-100 hover:bg-gray-200 text-gray-800 py-2 px-4 rounded-md transition-colors">
          Previous: Core Strengthening
        </Link>
        <Link href="/modules/daily-routines" className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors">
          Next Module: Daily Spine Care
        </Link>
      </div>
    </div>
  );
}
