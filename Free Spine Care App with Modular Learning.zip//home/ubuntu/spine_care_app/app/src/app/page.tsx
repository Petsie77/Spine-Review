import Link from "next/link";

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold text-blue-700 mb-4">Healthy Spine, Healthy Life</h1>
        <p className="text-xl text-gray-600">Learn how to care for your spine with expert guidance and exercises</p>
      </header>

      <section className="mb-12">
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-semibold text-blue-600 mb-4">Welcome to Your Spine Care Journey</h2>
          <p className="text-gray-700 mb-4">
            This app provides evidence-based guidance to help you understand, protect, and strengthen your spine.
            Our content is organized into easy-to-follow modules that cover everything from basic spine anatomy
            to specific exercises and daily habits for spine health.
          </p>
          <p className="text-gray-700">
            Each module includes educational content, visual demonstrations, and interactive exercises
            to help you build a healthier relationship with your spine.
          </p>
        </div>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold text-blue-600 mb-6">Explore Our Modules</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            {
              title: "Understanding Your Spine",
              description: "Learn about spine anatomy and function",
              href: "/modules/understanding-spine",
              color: "bg-blue-100",
            },
            {
              title: "Proper Posture",
              description: "Master the fundamentals of good posture",
              href: "/modules/proper-posture",
              color: "bg-green-100",
            },
            {
              title: "Sitting Ergonomics",
              description: "Set up your workspace for spine health",
              href: "/modules/sitting-ergonomics",
              color: "bg-yellow-100",
            },
            {
              title: "Core Strengthening",
              description: "Build a strong foundation for your spine",
              href: "/modules/core-strengthening",
              color: "bg-red-100",
            },
            {
              title: "Spine Flexibility",
              description: "Improve mobility and reduce stiffness",
              href: "/modules/spine-flexibility",
              color: "bg-purple-100",
            },
            {
              title: "Daily Spine Care",
              description: "Integrate spine health into your routine",
              href: "/modules/daily-spine-care",
              color: "bg-indigo-100",
            },
          ].map((module, index) => (
            <div key={index} className={`${module.color} rounded-lg shadow p-6 transition-transform hover:scale-105`}>
              <h3 className="text-xl font-semibold mb-2">{module.title}</h3>
              <p className="text-gray-700 mb-4">{module.description}</p>
              <Link href={module.href} className="text-blue-600 font-medium hover:underline">
                Explore Module →
              </Link>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-12">
        <div className="bg-blue-50 rounded-lg shadow p-6">
          <h2 className="text-2xl font-semibold text-blue-600 mb-4">Why Spine Health Matters</h2>
          <p className="text-gray-700 mb-4">
            Your spine is the central support structure of your body, protecting your spinal cord and allowing you
            to stand upright, bend, and twist. Taking care of your spine is essential for overall health and quality of life.
          </p>
          <p className="text-gray-700">
            Research shows that approximately 80% of people will experience significant back pain at some point in their lives.
            Many of these issues can be prevented or managed with proper knowledge and care.
          </p>
        </div>
      </section>

      <footer className="text-center text-gray-500 mt-12">
        <p>© 2025 Healthy Spine, Healthy Life | Created with evidence-based spine care practices</p>
      </footer>
    </div>
  );
}
