import React from "react";
import ModuleCard from "@/components/ui/module-card";

export default function ModulesPage() {
  const modules = [
    {
      title: "Understanding Your Spine",
      description: "Learn about spine anatomy, function, and common conditions.",
      icon: "🧠",
      href: "/modules/understanding-spine",
      color: "bg-blue-100",
    },
    {
      title: "Proper Posture Fundamentals",
      description: "Master the basics of good posture for a healthy spine.",
      icon: "🧍",
      href: "/modules/proper-posture",
      color: "bg-green-100",
    },
    {
      title: "Sitting Posture & Ergonomics",
      description: "Set up your workspace and learn proper sitting techniques.",
      icon: "🪑",
      href: "/modules/sitting-ergonomics",
      color: "bg-yellow-100",
    },
    {
      title: "Standing & Walking Posture",
      description: "Improve your posture while standing and walking.",
      icon: "👣",
      href: "/modules/standing-walking",
      color: "bg-orange-100",
    },
    {
      title: "Sleeping Posture & Habits",
      description: "Optimize your sleep position for spine health.",
      icon: "😴",
      href: "/modules/sleeping-posture",
      color: "bg-purple-100",
    },
    {
      title: "Core Strengthening Exercises",
      description: "Build a strong foundation to support your spine.",
      icon: "💪",
      href: "/modules/core-strengthening",
      color: "bg-red-100",
    },
    {
      title: "Spine Flexibility & Mobility",
      description: "Improve range of motion and reduce stiffness.",
      icon: "🤸",
      href: "/modules/spine-flexibility",
      color: "bg-indigo-100",
    },
    {
      title: "Daily Spine Care Routines",
      description: "Integrate spine health practices into your daily life.",
      icon: "📅",
      href: "/modules/daily-routines",
      color: "bg-teal-100",
    },
    {
      title: "Spine-Friendly Lifestyle",
      description: "Make choices that support long-term spine health.",
      icon: "🌱",
      href: "/modules/spine-friendly-lifestyle",
      color: "bg-pink-100",
    },
    {
      title: "Tracking & Progress",
      description: "Monitor your improvement and stay motivated.",
      icon: "📊",
      href: "/modules/tracking-progress",
      color: "bg-gray-100",
    },
  ];

  return (
    <div>
      <header className="mb-10">
        <h1 className="text-3xl font-bold text-blue-700 mb-4">Learning Modules</h1>
        <p className="text-gray-600">
          Explore our comprehensive modules to learn everything you need to know about spine care.
          Each module contains educational content, visual demonstrations, and practical exercises.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {modules.map((module, index) => (
          <ModuleCard
            key={index}
            title={module.title}
            description={module.description}
            icon={module.icon}
            href={module.href}
            color={module.color}
          />
        ))}
      </div>
    </div>
  );
}
