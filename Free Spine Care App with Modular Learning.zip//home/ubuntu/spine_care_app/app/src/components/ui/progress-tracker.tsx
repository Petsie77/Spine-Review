import React, { useState, useEffect } from "react";
import { useModuleProgress } from "@/hooks/useModuleProgress";

export default function ProgressTracker({ moduleId, moduleName, totalSections }) {
  const { progress, updateProgress, resetProgress } = useModuleProgress(moduleId);
  const [allModulesProgress, setAllModulesProgress] = useState([]);
  
  // Load all modules progress on component mount
  useEffect(() => {
    const loadAllProgress = () => {
      const modules = [
        { id: "understanding-spine", name: "Understanding Your Spine", totalSections: 5 },
        { id: "proper-posture", name: "Proper Posture Fundamentals", totalSections: 5 },
        { id: "sitting-ergonomics", name: "Sitting Posture & Ergonomics", totalSections: 5 },
        { id: "standing-walking", name: "Standing & Walking Posture", totalSections: 4 },
        { id: "sleeping-posture", name: "Sleeping Posture & Habits", totalSections: 4 },
        { id: "core-strengthening", name: "Core Strengthening Exercises", totalSections: 4 },
        { id: "spine-flexibility", name: "Spine Flexibility & Mobility", totalSections: 4 },
        { id: "daily-routines", name: "Daily Spine Care Routines", totalSections: 4 },
        { id: "spine-friendly-lifestyle", name: "Spine-Friendly Lifestyle", totalSections: 5 },
        { id: "tracking-progress", name: "Tracking & Progress", totalSections: 4 }
      ];
      
      const progressData = modules.map(module => {
        const savedProgress = localStorage.getItem(`module_progress_${module.id}`);
        if (savedProgress) {
          return {
            ...module,
            ...JSON.parse(savedProgress)
          };
        } else {
          return {
            ...module,
            completedSections: 0,
            percentage: 0
          };
        }
      });
      
      setAllModulesProgress(progressData);
    };
    
    loadAllProgress();
  }, []);
  
  // Calculate overall progress
  const calculateOverallProgress = () => {
    if (allModulesProgress.length === 0) return 0;
    
    const totalCompleted = allModulesProgress.reduce((sum, module) => sum + module.completedSections, 0);
    const totalSections = allModulesProgress.reduce((sum, module) => sum + module.totalSections, 0);
    
    return Math.round((totalCompleted / totalSections) * 100);
  };
  
  // Update current module progress
  const handleUpdateProgress = (completed) => {
    updateProgress(totalSections, completed);
    
    // Update the all modules progress state
    setAllModulesProgress(prev => 
      prev.map(module => 
        module.id === moduleId 
          ? { ...module, completedSections: completed, percentage: Math.round((completed / totalSections) * 100) }
          : module
      )
    );
  };
  
  // Reset current module progress
  const handleResetProgress = () => {
    resetProgress();
    
    // Update the all modules progress state
    setAllModulesProgress(prev => 
      prev.map(module => 
        module.id === moduleId 
          ? { ...module, completedSections: 0, percentage: 0 }
          : module
      )
    );
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h3 className="text-xl font-semibold text-blue-700 mb-4">Your Learning Progress</h3>
      
      {moduleId && moduleName && (
        <div className="mb-6">
          <h4 className="text-lg font-medium text-gray-800 mb-2">Current Module: {moduleName}</h4>
          
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-700">Progress</span>
            <span className="text-sm font-medium text-blue-600">{progress.percentage}% Complete</span>
          </div>
          
          <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
            <div 
              className="bg-blue-600 h-2.5 rounded-full" 
              style={{ width: `${progress.percentage}%` }}
            ></div>
          </div>
          
          <div className="flex flex-wrap gap-2 mb-4">
            {Array.from({ length: totalSections }, (_, i) => i + 1).map(section => (
              <button
                key={section}
                onClick={() => handleUpdateProgress(section)}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                  section <= progress.completedSections
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {section}
              </button>
            ))}
          </div>
          
          <button
            onClick={handleResetProgress}
            className="text-red-600 hover:text-red-800 text-sm font-medium transition-colors"
          >
            Reset Progress
          </button>
        </div>
      )}
      
      <div>
        <h4 className="text-lg font-medium text-gray-800 mb-3">Overall App Progress</h4>
        
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-gray-700">All Modules</span>
          <span className="text-sm font-medium text-blue-600">{calculateOverallProgress()}% Complete</span>
        </div>
        
        <div className="w-full bg-gray-200 rounded-full h-2.5 mb-6">
          <div 
            className="bg-green-600 h-2.5 rounded-full" 
            style={{ width: `${calculateOverallProgress()}%` }}
          ></div>
        </div>
        
        <div className="space-y-4">
          {allModulesProgress.map(module => (
            <div key={module.id}>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm font-medium text-gray-700">{module.name}</span>
                <span className="text-sm font-medium text-blue-600">{module.percentage}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-1.5">
                <div 
                  className={`h-1.5 rounded-full ${
                    module.percentage === 100 ? 'bg-green-600' : 'bg-blue-600'
                  }`}
                  style={{ width: `${module.percentage}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
