import React from "react";

interface ModuleProgressProps {
  totalSections: number;
  completedSections: number;
  moduleTitle: string;
}

export default function ModuleProgress({
  totalSections,
  completedSections,
  moduleTitle,
}: ModuleProgressProps) {
  const progressPercentage = Math.round((completedSections / totalSections) * 100);
  
  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-6">
      <div className="flex justify-between items-center mb-2">
        <h3 className="font-medium text-gray-700">{moduleTitle}</h3>
        <span className="text-sm font-medium text-blue-600">{progressPercentage}% Complete</span>
      </div>
      
      <div className="w-full bg-gray-200 rounded-full h-2.5">
        <div 
          className="bg-blue-600 h-2.5 rounded-full" 
          style={{ width: `${progressPercentage}%` }}
        ></div>
      </div>
      
      <div className="mt-2 text-sm text-gray-500">
        {completedSections} of {totalSections} sections completed
      </div>
    </div>
  );
}
