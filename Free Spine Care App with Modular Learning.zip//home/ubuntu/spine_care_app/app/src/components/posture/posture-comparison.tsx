import React from "react";
import Image from "next/image";

interface PostureComparisonProps {
  title: string;
  correctImageUrl: string;
  incorrectImageUrl: string;
  correctDescription: string;
  incorrectDescription: string;
  tips: string[];
}

export default function PostureComparison({
  title,
  correctImageUrl,
  incorrectImageUrl,
  correctDescription,
  incorrectDescription,
  tips,
}: PostureComparisonProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden p-6 mb-8">
      <h3 className="text-xl font-semibold text-gray-800 mb-4">{title}</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className="flex flex-col items-center">
          <div className="relative h-64 w-full mb-3 posture-image correct-posture">
            {correctImageUrl ? (
              <Image
                src={correctImageUrl}
                alt={`Correct ${title}`}
                fill
                className="object-contain"
              />
            ) : (
              <div className="h-full w-full bg-gray-200 flex items-center justify-center">
                <span className="text-gray-400">Image not available</span>
              </div>
            )}
            <div className="absolute top-2 right-2 bg-green-500 text-white px-2 py-1 rounded-md text-sm">
              Correct
            </div>
          </div>
          <p className="text-gray-700">{correctDescription}</p>
        </div>
        
        <div className="flex flex-col items-center">
          <div className="relative h-64 w-full mb-3 posture-image incorrect-posture">
            {incorrectImageUrl ? (
              <Image
                src={incorrectImageUrl}
                alt={`Incorrect ${title}`}
                fill
                className="object-contain"
              />
            ) : (
              <div className="h-full w-full bg-gray-200 flex items-center justify-center">
                <span className="text-gray-400">Image not available</span>
              </div>
            )}
            <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-md text-sm">
              Incorrect
            </div>
          </div>
          <p className="text-gray-700">{incorrectDescription}</p>
        </div>
      </div>
      
      <div className="mt-6 bg-blue-50 p-4 rounded-md">
        <h4 className="font-semibold text-blue-700 mb-2">Tips for Improvement</h4>
        <ul className="list-disc pl-5 space-y-1">
          {tips.map((tip, index) => (
            <li key={index} className="text-gray-700">{tip}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}
