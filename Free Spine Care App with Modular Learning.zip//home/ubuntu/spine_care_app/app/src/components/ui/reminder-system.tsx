import React, { useState, useEffect } from "react";

export default function ReminderSystem() {
  const [isEnabled, setIsEnabled] = useState(false);
  const [reminderInterval, setReminderInterval] = useState(30); // minutes
  const [reminderType, setReminderType] = useState("posture");
  const [notificationPermission, setNotificationPermission] = useState("default");
  const [lastReminderTime, setLastReminderTime] = useState(null);
  const [nextReminderTime, setNextReminderTime] = useState(null);

  // Check notification permission on component mount
  useEffect(() => {
    if ("Notification" in window) {
      setNotificationPermission(Notification.permission);
    }
  }, []);

  // Set up reminder timer when enabled
  useEffect(() => {
    let timer;
    
    if (isEnabled) {
      // Set initial next reminder time
      const now = new Date();
      const next = new Date(now.getTime() + reminderInterval * 60 * 1000);
      setNextReminderTime(next);
      
      // Set up interval to check if it's time for a reminder
      timer = setInterval(() => {
        const currentTime = new Date();
        if (nextReminderTime && currentTime >= nextReminderTime) {
          sendReminder();
          
          // Set next reminder time
          const newNextTime = new Date(currentTime.getTime() + reminderInterval * 60 * 1000);
          setNextReminderTime(newNextTime);
          setLastReminderTime(currentTime);
        }
      }, 10000); // Check every 10 seconds
    }
    
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isEnabled, reminderInterval, reminderType, nextReminderTime]);

  // Request notification permission
  const requestPermission = () => {
    if ("Notification" in window) {
      Notification.requestPermission().then(permission => {
        setNotificationPermission(permission);
      });
    }
  };

  // Send a reminder notification
  const sendReminder = () => {
    if (notificationPermission === "granted") {
      let title, body;
      
      switch (reminderType) {
        case "posture":
          title = "Posture Check";
          body = "Take a moment to check and reset your posture.";
          break;
        case "movement":
          title = "Movement Break";
          body = "Time to stand up and move around for a minute or two.";
          break;
        case "water":
          title = "Hydration Reminder";
          body = "Remember to drink water for spine disc health.";
          break;
        case "stretch":
          title = "Stretch Break";
          body = "Take a moment to do some gentle spine stretches.";
          break;
        default:
          title = "Spine Care Reminder";
          body = "Take a moment for your spine health.";
      }
      
      const notification = new Notification(title, {
        body: body,
        icon: "/icons/spine-icon.png" // This would need to be created
      });
      
      // Close notification after 5 seconds
      setTimeout(() => {
        notification.close();
      }, 5000);
    }
  };

  // Format time for display
  const formatTime = (date) => {
    if (!date) return "Not set";
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Toggle reminder system on/off
  const toggleReminders = () => {
    if (!isEnabled && notificationPermission !== "granted") {
      requestPermission();
    }
    setIsEnabled(!isEnabled);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h3 className="text-xl font-semibold text-blue-700 mb-4">Movement & Posture Reminders</h3>
      
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <span className="text-gray-700 font-medium">Enable Reminders</span>
          <label className="relative inline-flex items-center cursor-pointer">
            <input 
              type="checkbox" 
              className="sr-only peer"
              checked={isEnabled}
              onChange={toggleReminders}
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
          </label>
        </div>
        
        {notificationPermission !== "granted" && (
          <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-4">
            <p className="font-medium">Notification permission is required for reminders.</p>
            <button 
              onClick={requestPermission}
              className="mt-2 bg-yellow-500 hover:bg-yellow-600 text-white py-1 px-3 rounded-md text-sm transition-colors"
            >
              Request Permission
            </button>
          </div>
        )}
        
        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Reminder Type
          </label>
          <select
            value={reminderType}
            onChange={(e) => setReminderType(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={!isEnabled}
          >
            <option value="posture">Posture Check</option>
            <option value="movement">Movement Break</option>
            <option value="water">Hydration Reminder</option>
            <option value="stretch">Stretch Break</option>
          </select>
        </div>
        
        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Reminder Interval (minutes)
          </label>
          <input
            type="number"
            min="5"
            max="120"
            value={reminderInterval}
            onChange={(e) => setReminderInterval(parseInt(e.target.value, 10))}
            className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={!isEnabled}
          />
        </div>
        
        {isEnabled && (
          <div className="bg-blue-50 p-4 rounded-md">
            <p className="text-gray-700">
              <span className="font-medium">Last reminder:</span> {lastReminderTime ? formatTime(lastReminderTime) : "None yet"}
            </p>
            <p className="text-gray-700">
              <span className="font-medium">Next reminder:</span> {formatTime(nextReminderTime)}
            </p>
          </div>
        )}
        
        <div className="text-center">
          <button
            onClick={sendReminder}
            className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors"
            disabled={!isEnabled || notificationPermission !== "granted"}
          >
            Test Reminder Now
          </button>
        </div>
      </div>
    </div>
  );
}
