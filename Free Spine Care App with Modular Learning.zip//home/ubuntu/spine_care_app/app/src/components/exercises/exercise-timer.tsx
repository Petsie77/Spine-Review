import React, { useState } from "react";

export default function ExerciseTimer({ defaultDuration = 30 }) {
  const [duration, setDuration] = useState(defaultDuration);
  const [timeRemaining, setTimeRemaining] = useState(defaultDuration);
  const [isActive, setIsActive] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [timerType, setTimerType] = useState('countdown'); // 'countdown' or 'stopwatch'

  // Format time as MM:SS
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Start the timer
  const startTimer = () => {
    if (!isActive) {
      setIsActive(true);
      setIsPaused(false);
      
      const timer = setInterval(() => {
        setTimeRemaining((prevTime) => {
          if (timerType === 'countdown') {
            if (prevTime <= 1) {
              clearInterval(timer);
              setIsActive(false);
              return 0;
            }
            return prevTime - 1;
          } else {
            return prevTime + 1;
          }
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  };

  // Pause the timer
  const pauseTimer = () => {
    setIsPaused(true);
    setIsActive(false);
  };

  // Reset the timer
  const resetTimer = () => {
    setIsActive(false);
    setIsPaused(false);
    if (timerType === 'countdown') {
      setTimeRemaining(duration);
    } else {
      setTimeRemaining(0);
    }
  };

  // Toggle between countdown and stopwatch
  const toggleTimerType = () => {
    setIsActive(false);
    setIsPaused(false);
    if (timerType === 'countdown') {
      setTimerType('stopwatch');
      setTimeRemaining(0);
    } else {
      setTimerType('countdown');
      setTimeRemaining(duration);
    }
  };

  // Update duration (for countdown timer)
  const handleDurationChange = (e) => {
    const newDuration = parseInt(e.target.value, 10);
    setDuration(newDuration);
    if (!isActive && timerType === 'countdown') {
      setTimeRemaining(newDuration);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h3 className="text-xl font-semibold text-blue-700 mb-4">Exercise Timer</h3>
      
      <div className="flex flex-col items-center">
        <div className="text-5xl font-bold text-gray-800 mb-6">
          {formatTime(timeRemaining)}
        </div>
        
        <div className="flex space-x-4 mb-6">
          {!isActive && !isPaused ? (
            <button 
              onClick={startTimer}
              className="bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-md transition-colors"
            >
              Start
            </button>
          ) : isActive ? (
            <button 
              onClick={pauseTimer}
              className="bg-yellow-500 hover:bg-yellow-600 text-white py-2 px-4 rounded-md transition-colors"
            >
              Pause
            </button>
          ) : (
            <button 
              onClick={startTimer}
              className="bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-md transition-colors"
            >
              Resume
            </button>
          )}
          
          <button 
            onClick={resetTimer}
            className="bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-md transition-colors"
          >
            Reset
          </button>
          
          <button 
            onClick={toggleTimerType}
            className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors"
          >
            {timerType === 'countdown' ? 'Switch to Stopwatch' : 'Switch to Countdown'}
          </button>
        </div>
        
        {timerType === 'countdown' && (
          <div className="w-full max-w-xs">
            <label className="block text-gray-700 text-sm font-bold mb-2">
              Duration (seconds):
            </label>
            <input
              type="number"
              min="5"
              max="3600"
              value={duration}
              onChange={handleDurationChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              disabled={isActive}
            />
          </div>
        )}
      </div>
    </div>
  );
}
