import React from "react";

interface AnimationPlayerProps {
  animationUrl: string;
  title: string;
  description?: string;
  autoplay?: boolean;
  loop?: boolean;
}

export default function AnimationPlayer({
  animationUrl,
  title,
  description,
  autoplay = true,
  loop = true,
}: AnimationPlayerProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
      <div className="p-4">
        <div className="flex justify-center mb-4">
          <lottie-player
            src={animationUrl}
            background="transparent"
            speed="1"
            style={{ width: "300px", height: "300px" }}
            autoplay={autoplay ? "true" : "false"}
            loop={loop ? "true" : "false"}
          ></lottie-player>
        </div>
        
        {(title || description) && (
          <div className="text-center">
            {title && <h3 className="text-xl font-semibold text-gray-800 mb-2">{title}</h3>}
            {description && <p className="text-gray-600">{description}</p>}
          </div>
        )}
      </div>
    </div>
  );
}
