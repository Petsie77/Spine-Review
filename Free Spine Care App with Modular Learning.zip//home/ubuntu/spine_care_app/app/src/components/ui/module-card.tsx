import React from "react";
import Link from "next/link";

interface ModuleCardProps {
  title: string;
  description: string;
  icon: string;
  href: string;
  color: string;
}

export default function ModuleCard({
  title,
  description,
  icon,
  href,
  color,
}: ModuleCardProps) {
  return (
    <div className={`${color} rounded-lg shadow p-6 module-card`}>
      <div className="flex items-center mb-4">
        <span className="text-2xl mr-3" aria-hidden="true">
          {icon}
        </span>
        <h3 className="text-xl font-semibold">{title}</h3>
      </div>
      <p className="text-gray-700 mb-4">{description}</p>
      <Link href={href} className="text-blue-600 font-medium hover:underline inline-flex items-center">
        Explore Module
        <svg 
          xmlns="http://www.w3.org/2000/svg" 
          className="h-4 w-4 ml-1" 
          fill="none" 
          viewBox="0 0 24 24" 
          stroke="currentColor"
        >
          <path 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth={2} 
            d="M9 5l7 7-7 7" 
          />
        </svg>
      </Link>
    </div>
  );
}
