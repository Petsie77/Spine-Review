import Link from "next/link";

export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-200 py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-blue-700 mb-4">Healthy Spine, Healthy Life</h3>
            <p className="text-gray-600">
              Evidence-based guidance to help you understand, protect, and strengthen your spine.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-blue-700 mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/modules" className="text-gray-600 hover:text-blue-700">
                  All Modules
                </Link>
              </li>
              <li>
                <Link href="/exercises" className="text-gray-600 hover:text-blue-700">
                  Exercise Library
                </Link>
              </li>
              <li>
                <Link href="/posture" className="text-gray-600 hover:text-blue-700">
                  Posture Guide
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-blue-700 mb-4">Resources</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-gray-600 hover:text-blue-700">
                  About This App
                </Link>
              </li>
              <li>
                <Link href="/references" className="text-gray-600 hover:text-blue-700">
                  References
                </Link>
              </li>
              <li>
                <Link href="/disclaimer" className="text-gray-600 hover:text-blue-700">
                  Medical Disclaimer
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-200 mt-8 pt-8 text-center text-gray-500">
          <p>© 2025 Healthy Spine, Healthy Life | Created with evidence-based spine care practices</p>
          <p className="mt-2 text-sm">
            This app is for educational purposes only and is not a substitute for professional medical advice.
          </p>
        </div>
      </div>
    </footer>
  );
}
