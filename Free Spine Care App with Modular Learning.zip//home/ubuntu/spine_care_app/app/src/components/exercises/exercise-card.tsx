import React from "react";
import Image from "next/image";

interface ExerciseCardProps {
  title: string;
  description: string;
  imageUrl: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  targetAreas: string[];
  duration: string;
}

export default function ExerciseCard({
  title,
  description,
  imageUrl,
  difficulty,
  targetAreas,
  duration,
}: ExerciseCardProps) {
  const difficultyColor = {
    beginner: "bg-green-100 text-green-800",
    intermediate: "bg-yellow-100 text-yellow-800",
    advanced: "bg-red-100 text-red-800",
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:shadow-lg">
      <div className="relative h-48 w-full">
        {imageUrl ? (
          <Image
            src={imageUrl}
            alt={title}
            fill
            className="object-cover"
          />
        ) : (
          <div className="h-full w-full bg-gray-200 flex items-center justify-center">
            <span className="text-gray-400">Image not available</span>
          </div>
        )}
      </div>
      <div className="p-4">
        <h3 className="text-xl font-semibold text-gray-800 mb-2">{title}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        
        <div className="flex flex-wrap gap-2 mb-3">
          <span className={`text-xs px-2 py-1 rounded-full ${difficultyColor[difficulty]}`}>
            {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
          </span>
          <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800">
            {duration}
          </span>
        </div>
        
        <div className="mt-3">
          <p className="text-sm text-gray-500 mb-1">Target areas:</p>
          <div className="flex flex-wrap gap-1">
            {targetAreas.map((area, index) => (
              <span key={index} className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-700">
                {area}
              </span>
            ))}
          </div>
        </div>
        
        <button className="mt-4 w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors">
          View Exercise
        </button>
      </div>
    </div>
  );
}
