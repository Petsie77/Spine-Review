import React, { useState } from "react";

export default function PostureAssessmentTool() {
  const [assessmentStep, setAssessmentStep] = useState(1);
  const [answers, setAnswers] = useState({});
  const [results, setResults] = useState(null);

  const questions = [
    {
      id: 1,
      text: "When sitting at a desk, where are your ears positioned relative to your shoulders?",
      options: [
        { value: "aligned", text: "Directly above my shoulders", score: 2 },
        { value: "slightly_forward", text: "Slightly forward of my shoulders", score: 1 },
        { value: "far_forward", text: "Far forward of my shoulders", score: 0 }
      ]
    },
    {
      id: 2,
      text: "When standing naturally, what is the position of your shoulders?",
      options: [
        { value: "back_relaxed", text: "Back and relaxed", score: 2 },
        { value: "slightly_rounded", text: "Slightly rounded forward", score: 1 },
        { value: "very_rounded", text: "Very rounded forward", score: 0 }
      ]
    },
    {
      id: 3,
      text: "When you look at your side profile in a mirror, how would you describe your lower back curve?",
      options: [
        { value: "natural", text: "Natural slight curve", score: 2 },
        { value: "flat", text: "Flattened (reduced curve)", score: 1 },
        { value: "excessive", text: "Excessive curve (arched)", score: 0 }
      ]
    },
    {
      id: 4,
      text: "How do you typically stand for extended periods?",
      options: [
        { value: "weight_even", text: "Weight evenly distributed on both feet", score: 2 },
        { value: "shift_occasionally", text: "Shifting weight occasionally between feet", score: 1 },
        { value: "lean_one_side", text: "Leaning heavily to one side", score: 0 }
      ]
    },
    {
      id: 5,
      text: "When sitting, how do you position your feet?",
      options: [
        { value: "flat_floor", text: "Flat on the floor with knees at 90 degrees", score: 2 },
        { value: "crossed_occasionally", text: "Crossed occasionally", score: 1 },
        { value: "crossed_always", text: "Always crossed or tucked under chair", score: 0 }
      ]
    }
  ];

  const handleAnswer = (questionId, value, score) => {
    setAnswers({
      ...answers,
      [questionId]: { value, score }
    });
  };

  const nextStep = () => {
    if (assessmentStep < questions.length) {
      setAssessmentStep(assessmentStep + 1);
    } else {
      calculateResults();
    }
  };

  const prevStep = () => {
    if (assessmentStep > 1) {
      setAssessmentStep(assessmentStep - 1);
    }
  };

  const calculateResults = () => {
    const totalScore = Object.values(answers).reduce((sum, answer) => sum + answer.score, 0);
    const maxPossibleScore = questions.length * 2;
    const percentage = Math.round((totalScore / maxPossibleScore) * 100);
    
    let assessment;
    let recommendations = [];
    
    if (percentage >= 80) {
      assessment = "Excellent Posture";
      recommendations = [
        "Continue maintaining your excellent posture habits",
        "Consider incorporating regular mobility exercises to maintain flexibility",
        "Share your posture knowledge with friends and family"
      ];
    } else if (percentage >= 60) {
      assessment = "Good Posture with Minor Issues";
      recommendations = [
        "Focus on the specific areas where you scored lower",
        "Set reminders to check your posture throughout the day",
        "Review the proper posture and ergonomics modules"
      ];
    } else if (percentage >= 40) {
      assessment = "Moderate Posture Concerns";
      recommendations = [
        "Prioritize the core strengthening exercises in the app",
        "Set up your workstation according to ergonomic guidelines",
        "Practice the standing and sitting posture techniques daily"
      ];
    } else {
      assessment = "Significant Posture Improvement Needed";
      recommendations = [
        "Consider consulting with a healthcare professional",
        "Start with the basic posture exercises in the app",
        "Make environmental changes to support better posture",
        "Set hourly reminders to reset your posture"
      ];
    }
    
    setResults({
      score: totalScore,
      maxScore: maxPossibleScore,
      percentage,
      assessment,
      recommendations
    });
  };

  const resetAssessment = () => {
    setAssessmentStep(1);
    setAnswers({});
    setResults(null);
  };

  const currentQuestion = questions[assessmentStep - 1];

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h3 className="text-xl font-semibold text-blue-700 mb-4">Posture Assessment Tool</h3>
      
      {!results ? (
        <div>
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700">Question {assessmentStep} of {questions.length}</span>
              <span className="text-sm font-medium text-blue-600">{Math.round((assessmentStep / questions.length) * 100)}% Complete</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="bg-blue-600 h-2.5 rounded-full" 
                style={{ width: `${(assessmentStep / questions.length) * 100}%` }}
              ></div>
            </div>
          </div>
          
          <div className="mb-6">
            <h4 className="text-lg font-medium text-gray-800 mb-4">{currentQuestion.text}</h4>
            <div className="space-y-3">
              {currentQuestion.options.map((option) => (
                <div key={option.value} className="flex items-center">
                  <input
                    type="radio"
                    id={option.value}
                    name={`question-${currentQuestion.id}`}
                    value={option.value}
                    checked={answers[currentQuestion.id]?.value === option.value}
                    onChange={() => handleAnswer(currentQuestion.id, option.value, option.score)}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                  />
                  <label htmlFor={option.value} className="ml-2 text-gray-700">
                    {option.text}
                  </label>
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex justify-between">
            <button
              onClick={prevStep}
              disabled={assessmentStep === 1}
              className={`py-2 px-4 rounded-md transition-colors ${
                assessmentStep === 1 
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed' 
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
              }`}
            >
              Previous
            </button>
            <button
              onClick={nextStep}
              disabled={!answers[currentQuestion.id]}
              className={`py-2 px-4 rounded-md transition-colors ${
                !answers[currentQuestion.id]
                  ? 'bg-blue-300 text-white cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-700 text-white'
              }`}
            >
              {assessmentStep === questions.length ? 'See Results' : 'Next'}
            </button>
          </div>
        </div>
      ) : (
        <div>
          <div className="text-center mb-6">
            <h4 className="text-2xl font-bold text-gray-800 mb-2">{results.assessment}</h4>
            <div className="inline-block bg-blue-100 text-blue-800 text-xl font-semibold px-4 py-2 rounded-full mb-4">
              Score: {results.score}/{results.maxScore} ({results.percentage}%)
            </div>
            <div className="w-full bg-gray-200 rounded-full h-4 mb-4">
              <div 
                className={`h-4 rounded-full ${
                  results.percentage >= 80 ? 'bg-green-600' :
                  results.percentage >= 60 ? 'bg-blue-600' :
                  results.percentage >= 40 ? 'bg-yellow-500' : 'bg-red-600'
                }`}
                style={{ width: `${results.percentage}%` }}
              ></div>
            </div>
          </div>
          
          <div className="mb-6">
            <h4 className="text-lg font-semibold text-blue-700 mb-3">Recommendations:</h4>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              {results.recommendations.map((recommendation, index) => (
                <li key={index}>{recommendation}</li>
              ))}
            </ul>
          </div>
          
          <div className="text-center">
            <button
              onClick={resetAssessment}
              className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-6 rounded-md transition-colors"
            >
              Take Assessment Again
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
