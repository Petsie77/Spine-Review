import React from "react";

interface VideoPlayerProps {
  videoUrl: string;
  title: string;
  description?: string;
}

export default function VideoPlayer({
  videoUrl,
  title,
  description,
}: VideoPlayerProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
      <div className="exercise-video">
        <iframe
          width="100%"
          height="315"
          src={videoUrl}
          title={title}
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          className="w-full"
        ></iframe>
      </div>
      
      {(title || description) && (
        <div className="p-4">
          {title && <h3 className="text-xl font-semibold text-gray-800 mb-2">{title}</h3>}
          {description && <p className="text-gray-600">{description}</p>}
        </div>
      )}
    </div>
  );
}
