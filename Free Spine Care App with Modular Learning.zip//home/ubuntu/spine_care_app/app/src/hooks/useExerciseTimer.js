import { useState, useEffect } from 'react';

export function useExerciseTimer() {
  const [isRunning, setIsRunning] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [timerType, setTimerType] = useState('countdown'); // 'countdown' or 'stopwatch'
  const [initialTime, setInitialTime] = useState(30); // Default 30 seconds for countdown

  useEffect(() => {
    let interval = null;
    
    if (isRunning) {
      interval = setInterval(() => {
        if (timerType === 'countdown') {
          setSeconds(prevSeconds => {
            if (prevSeconds <= 1) {
              clearInterval(interval);
              setIsRunning(false);
              return 0;
            }
            return prevSeconds - 1;
          });
        } else {
          setSeconds(prevSeconds => prevSeconds + 1);
        }
      }, 1000);
    } else if (!isRunning && seconds !== 0 && timerType === 'stopwatch') {
      clearInterval(interval);
    }
    
    return () => clearInterval(interval);
  }, [isRunning, seconds, timerType]);

  const startTimer = () => {
    if (timerType === 'countdown' && seconds === 0) {
      setSeconds(initialTime);
    }
    setIsRunning(true);
  };

  const pauseTimer = () => {
    setIsRunning(false);
  };

  const resetTimer = () => {
    setIsRunning(false);
    if (timerType === 'countdown') {
      setSeconds(initialTime);
    } else {
      setSeconds(0);
    }
  };

  const setCountdownTime = (time) => {
    setInitialTime(time);
    if (!isRunning) {
      setSeconds(time);
    }
  };

  const toggleTimerType = () => {
    setIsRunning(false);
    if (timerType === 'countdown') {
      setTimerType('stopwatch');
      setSeconds(0);
    } else {
      setTimerType('countdown');
      setSeconds(initialTime);
    }
  };

  const formatTime = () => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return {
    isRunning,
    seconds,
    timerType,
    startTimer,
    pauseTimer,
    resetTimer,
    setCountdownTime,
    toggleTimerType,
    formatTime
  };
}
