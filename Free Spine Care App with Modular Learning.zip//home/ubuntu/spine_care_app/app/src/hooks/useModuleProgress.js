import { useState, useEffect } from 'react';

export function useModuleProgress(moduleId) {
  const [progress, setProgress] = useState({
    totalSections: 0,
    completedSections: 0,
    percentage: 0
  });

  useEffect(() => {
    // Load progress from localStorage on component mount
    const savedProgress = localStorage.getItem(`module_progress_${moduleId}`);
    
    if (savedProgress) {
      setProgress(JSON.parse(savedProgress));
    }
  }, [moduleId]);

  const updateProgress = (totalSections, completedSections) => {
    const percentage = Math.round((completedSections / totalSections) * 100);
    const newProgress = { totalSections, completedSections, percentage };
    
    // Save to localStorage
    localStorage.setItem(`module_progress_${moduleId}`, JSON.stringify(newProgress));
    setProgress(newProgress);
  };

  const markSectionComplete = (sectionId) => {
    const newCompletedSections = progress.completedSections + 1;
    updateProgress(progress.totalSections, newCompletedSections);
    
    // Save completed section ID to localStorage
    const completedSections = JSON.parse(localStorage.getItem(`module_${moduleId}_completed_sections`) || '[]');
    if (!completedSections.includes(sectionId)) {
      completedSections.push(sectionId);
      localStorage.setItem(`module_${moduleId}_completed_sections`, JSON.stringify(completedSections));
    }
  };

  const resetProgress = () => {
    updateProgress(progress.totalSections, 0);
    localStorage.removeItem(`module_${moduleId}_completed_sections`);
  };

  const isSectionCompleted = (sectionId) => {
    const completedSections = JSON.parse(localStorage.getItem(`module_${moduleId}_completed_sections`) || '[]');
    return completedSections.includes(sectionId);
  };

  return {
    progress,
    updateProgress,
    markSectionComplete,
    resetProgress,
    isSectionCompleted
  };
}
